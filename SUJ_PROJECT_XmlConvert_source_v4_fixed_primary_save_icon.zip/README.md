# SUJ PROJECT – XmlConvert v1.3

Perbaikan dilakukan pada source ZIP yang diberikan pengguna (`SUJ_PROJECT_XmlConvert_source_v4_xmlfix_flat(7).zip`).

## Perubahan
- Nama XML dibaca dari `OpenableColumns.DISPLAY_NAME` milik penyedia dokumen Android. Label memakai nama file sebenarnya (misalnya `primary:proyek baru 118.xml`), bukan ID internal seperti `primary:document:1000032683`.
- Menambahkan ikon launcher SUJ PROJECT dan memakai ikon yang sama pada menu XmlConvert.
- Tombol SIMPAN membuka pemilih lokasi simpan, menulis XML UTF-8 sampai selesai, lalu menampilkan nama file yang disimpan atau pesan kesalahan.
- Nama hasil simpan mengikuti nama XML sumber dengan akhiran `_converted.xml`.
- Versi aplikasi dinaikkan ke 1.3.

## Build APK
Jalankan GitHub Actions workflow `Build SUJ PROJECT APK`. Artifact bernama `SUJ-PROJECT-debug-APK`.

## Batasan format
Aplikasi ini mengubah atribut `fillImage` menjadi URI Android untuk foto yang dipilih. Itu belum menjamin URI tersebut kompatibel dengan format proyek/draf privat CapCut. Nama proyek pada UI juga masih label yang dimasukkan pengguna, bukan pembacaan otomatis folder privat CapCut.

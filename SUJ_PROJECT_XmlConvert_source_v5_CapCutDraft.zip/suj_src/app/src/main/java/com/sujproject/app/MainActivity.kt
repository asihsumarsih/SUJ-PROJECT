package com.sujproject.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.xml.sax.InputSource
import java.io.StringReader
import java.io.StringWriter
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import org.json.JSONArray
import org.json.JSONObject
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

class MainActivity : ComponentActivity() {
    private val black = Color.rgb(12, 12, 12)
    private val card = Color.rgb(35, 35, 35)
    private val purple = Color.rgb(174, 0, 220)
    private val green = Color.rgb(50, 220, 95)
    private val white = Color.WHITE

    private var xmlText = ""
    private var xmlName = ""
    private var draftName = "1021-03 (IKP2)"
    private var mediaRefs = mutableListOf<String>()
    private var selectedPhotos = mutableMapOf<Int, Uri>()
    private lateinit var page: LinearLayout
    private lateinit var xmlStatus: TextView
    private lateinit var mediaArea: LinearLayout
    private lateinit var bottomStatus: TextView

    private val importXml = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            try {
                xmlText = contentResolver.openInputStream(uri)?.use { input ->
                    val bytes = input.readBytes()
                    decodeXml(bytes)
                } ?: error("File tidak dapat dibaca")
                val parsed = parseMedia(xmlText)
                mediaRefs = parsed.toMutableList()
                selectedPhotos.clear()
                xmlName = getDisplayName(uri) ?: "Proyek.xml"
                renderConverter()
                xmlStatus.text = "● primary:$xmlName"
                xmlStatus.setTextColor(green)
                bottomStatus.text = "Terdeteksi ${mediaRefs.size} foto di XML. Silakan pilih foto pengganti."
                bottomStatus.setTextColor(green)
            } catch (e: Exception) {
                xmlText = ""
                mediaRefs.clear()
                renderConverter()
                xmlStatus.text = "● XML gagal dimuat: ${e.message ?: "format tidak dikenali"}"
                xmlStatus.setTextColor(Color.RED)
            }
        }
    }

    private var pickingIndex = -1
    private val pickPhoto = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null && pickingIndex >= 0) {
            try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            selectedPhotos[pickingIndex] = uri
            renderMediaRows()
            bottomStatus.text = "Foto ${pickingIndex + 1} berhasil dipilih."
            bottomStatus.setTextColor(green)
        }
    }

    private val saveProject = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) saveConverted(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        showHome()
    }

    private fun showHome() {
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(24), dp(30), dp(24), dp(24))
        }
        val title = TextView(this).apply {
            text = "SUJ PROJECT"
            textSize = 28f
            setTextColor(Color.BLACK)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(10), 0, dp(38))
        }
        root.addView(title)
        val menu = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val icon = TextView(this).apply {
            text = "↕"
            textSize = 48f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        val label = TextView(this).apply {
            text = "XmlConvert"
            textSize = 14f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        menu.addView(icon, LinearLayout.LayoutParams(dp(110), dp(68)))
        menu.addView(label, LinearLayout.LayoutParams(dp(110), dp(30)))
        menu.setOnClickListener { renderConverter() }
        root.addView(menu, LinearLayout.LayoutParams(dp(130), dp(110)))
        setContentView(root)
    }

    private fun renderConverter() {
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(black) }
        val scroll = ScrollView(this)
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(black)
            setPadding(dp(18), dp(24), dp(18), dp(12))
        }
        val projectLabel = TextView(this).apply {
            text = "PILIH PROYEK (DRAF)"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(20))
        }
        page.addView(projectLabel)
        val project = TextView(this).apply {
            text = draftName + "   ▾"
            textSize = 16f
            setTextColor(white)
            setPadding(dp(8), dp(8), dp(8), dp(12))
            setOnClickListener {
                val edit = EditText(this@MainActivity).apply { setText(draftName); setSingleLine(true) }
                AlertDialog.Builder(this@MainActivity).setTitle("Pilih Proyek (Draf)")
                    .setMessage("Masukkan nama draf CapCut yang ingin digunakan")
                    .setView(edit).setNegativeButton("BATAL", null)
                    .setPositiveButton("OK") { _, _ -> draftName = edit.text.toString().ifBlank { draftName }; renderConverter() }.show()
            }
        }
        page.addView(project)
        xmlStatus = TextView(this).apply {
            text = if (xmlText.isBlank()) "● XML Belum Dimuat" else "● primary:$xmlName"
            textSize = 14f
            setTextColor(if (xmlText.isBlank()) Color.rgb(240, 75, 115) else green)
            setPadding(0, dp(8), 0, dp(16))
        }
        page.addView(xmlStatus)
        val import = TextView(this).apply {
            text = "IMPORT XML"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(white)
            setBackgroundColor(card)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { importXml.launch(arrayOf("application/xml", "text/xml", "application/*", "*/*")) }
        }
        page.addView(import, LinearLayout.LayoutParams(-1, dp(48)))
        val mediaTitle = TextView(this).apply {
            text = "Media dalam Draf"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(white)
            setPadding(0, dp(32), 0, dp(24))
        }
        page.addView(mediaTitle)
        mediaArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(mediaArea)
        bottomStatus = TextView(this).apply {
            text = if (mediaRefs.isEmpty()) "Menunggu perintah..." else "Terdeteksi ${mediaRefs.size} foto di XML. Silakan pilih foto pengganti."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
            setPadding(dp(4), dp(18), dp(4), dp(14))
        }
        page.addView(bottomStatus)
        scroll.addView(page)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(8), dp(14), dp(12))
            setBackgroundColor(black)
        }
        val cancel = actionButton("BATAL", Color.rgb(65,65,65)) { showHome() }
        val save = actionButton("SIMPAN", purple) {
            if (xmlText.isBlank()) Toast.makeText(this, "Import XML terlebih dahulu", Toast.LENGTH_SHORT).show()
            else if (mediaRefs.isNotEmpty() && selectedPhotos.size < mediaRefs.size) {
                bottomStatus.text = "Pilih semua ${mediaRefs.size} foto terlebih dahulu."
                bottomStatus.setTextColor(Color.RED)
            } else saveProject.launch((draftName.ifBlank { "SUJ_PROJECT" }).replace(Regex("[^A-Za-z0-9._ -]"), "_") + "_CapCut_Project.zip")
        }
        buttons.addView(cancel, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(8) })
        buttons.addView(save, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(8) })
        outer.addView(buttons)
        setContentView(outer)
        renderMediaRows()
    }

    private fun renderMediaRows() {
        if (!::mediaArea.isInitialized) return
        mediaArea.removeAllViews()
        if (mediaRefs.isEmpty()) return
        val ranges = findRanges(xmlText, mediaRefs.size)
        val hint = TextView(this).apply {
            text = "Diperlukan ${mediaRefs.size} Foto (Klik untuk ganti dari Galeri)"
            textSize = 13f
            setTextColor(purple)
            setPadding(0, 0, 0, dp(12))
        }
        mediaArea.addView(hint)
        mediaRefs.forEachIndexed { index, ref ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
                setBackgroundColor(Color.rgb(27,27,27))
            }
            val thumb = TextView(this).apply {
                text = if (selectedPhotos.containsKey(index)) "✓" else "▧"
                textSize = 25f
                gravity = Gravity.CENTER
                setTextColor(if (selectedPhotos.containsKey(index)) green else Color.GRAY)
                setBackgroundColor(card)
            }
            row.addView(thumb, LinearLayout.LayoutParams(dp(66), dp(66)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(6), 0) }
            val title = TextView(this).apply { text = "Foto ${index + 1}  (${ranges.getOrNull(index) ?: "Media XML"})"; textSize = 14f; setTextColor(white) }
            val sub = TextView(this).apply {
                text = "Asli: ${ref.take(34)}${if (ref.length > 34) "..." else ""}"
                textSize = 10f; setTextColor(Color.LTGRAY); setPadding(0, dp(4), 0, 0)
            }
            info.addView(title); info.addView(sub)
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val choose = TextView(this).apply {
                text = if (selectedPhotos.containsKey(index)) "GANTI" else "PILIH"
                textSize = 12f; gravity = Gravity.CENTER; setTextColor(white); setBackgroundColor(Color.rgb(116, 0, 150)); setPadding(dp(12), dp(12), dp(12), dp(12))
                setOnClickListener { pickingIndex = index; pickPhoto.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
            }
            row.addView(choose, LinearLayout.LayoutParams(dp(68), dp(42)))
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            mediaArea.addView(row, lp)
        }
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 16f; gravity = Gravity.CENTER; setTextColor(white); setBackgroundColor(color)
        setOnClickListener { click() }
    }

    // Use the document provider's display name, not its opaque URI/document ID.
    private fun getDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (column >= 0) return cursor.getString(column)
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.contains('.') }
    }

    // Decode XML using its BOM or XML declaration; remove a UTF-8 BOM before parsing.
    private fun decodeXml(bytes: ByteArray): String {
        if (bytes.isEmpty()) error("File XML kosong")
        val decoded = when {
            bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte() ->
                String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
            bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte() ->
                String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
            bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte() ->
                String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
            else -> String(bytes, Charsets.UTF_8)
        }
        return decoded.trimStart('\uFEFF', '\u0000', ' ', '\n', '\r', '\t')
    }

    private fun allElements(doc: Document): List<Element> {
        val nodes = doc.getElementsByTagName("*")
        val result = ArrayList<Element>(nodes.length)
        for (i in 0 until nodes.length) {
            (nodes.item(i) as? Element)?.let { result.add(it) }
        }
        return result
    }

    private fun tagName(el: Element): String =
        (el.localName ?: el.tagName.substringAfter(':')).lowercase()

    private fun attr(el: Element, name: String): String {
        if (el.hasAttribute(name)) return el.getAttribute(name)
        val attrs = el.attributes
        for (i in 0 until attrs.length) {
            val node = attrs.item(i)
            if ((node.localName ?: node.nodeName.substringAfter(':')).equals(name, true)) {
                return node.nodeValue ?: ""
            }
        }
        return ""
    }

    // Only Android gallery image references are replaceable photo slots.
    // Alight Motion internal assets (for example am:...jpg) must stay untouched.
    private fun isReplaceablePhotoReference(value: String): Boolean {
        val v = value.trim().lowercase()
        return v.startsWith("content://media/external/images/") ||
            v.startsWith("content://media/external/image/")
    }

    private fun parseMedia(source: String): List<String> {
        require(source.isNotBlank()) { "File XML kosong" }
        val doc = parseDocument(source)
        val found = linkedSetOf<String>()
        for (el in allElements(doc)) {
            if (tagName(el) != "shape" || !attr(el, "fillType").equals("media", true)) continue
            val value = attr(el, "fillImage").ifBlank { attr(el, "media") }
            if (isReplaceablePhotoReference(value)) found.add(value)
        }
        return found.toList()
    }

    private fun parseDocument(source: String): Document {
        val clean = source.trimStart('\uFEFF', '\u0000', ' ', '\n', '\r', '\t')
        require(clean.isNotBlank()) { "File XML kosong" }
        val factory = DocumentBuilderFactory.newInstance()
        factory.isNamespaceAware = true
        factory.isExpandEntityReferences = false
        // Android versions differ in which parser security features they support.
        try { factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (_: Exception) { }
        try { factory.setFeature("http://xml.org/sax/features/external-general-entities", false) } catch (_: Exception) { }
        try { factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false) } catch (_: Exception) { }
        val builder = factory.newDocumentBuilder()
        builder.setEntityResolver { _, _ -> InputSource(StringReader("")) }
        return builder.parse(InputSource(StringReader(clean)))
    }

    private fun findRanges(source: String, count: Int): List<String> {
        val doc = try { parseDocument(source) } catch (_: Exception) { return emptyList() }
        data class Span(var start: Long, var end: Long)
        val spans = linkedMapOf<String, Span>()
        for (el in allElements(doc)) {
            if (tagName(el) != "shape" || !attr(el, "fillType").equals("media", true)) continue
            val value = attr(el, "fillImage").ifBlank { attr(el, "media") }
            if (!isReplaceablePhotoReference(value)) continue
            val start = attr(el, "startTime").toLongOrNull() ?: continue
            val end = attr(el, "endTime").toLongOrNull() ?: continue
            val span = spans[value]
            if (span == null) spans[value] = Span(start, end)
            else {
                if (start < span.start) span.start = start
                if (end > span.end) span.end = end
            }
        }
        return spans.values.take(count).map {
            "%.2fs - %.2fs".format(it.start / 1000.0, it.end / 1000.0)
        }
    }

    private data class MediaSlot(val ref: String, val startMs: Long, val endMs: Long)

    private fun collectMediaSlots(): List<MediaSlot> {
        val doc = parseDocument(xmlText)
        val slots = linkedMapOf<String, MediaSlot>()
        for (el in allElements(doc)) {
            if (tagName(el) != "shape" || !attr(el, "fillType").equals("media", true)) continue
            val ref = attr(el, "fillImage").ifBlank { attr(el, "media") }
            if (!isReplaceablePhotoReference(ref)) continue
            val start = attr(el, "startTime").toLongOrNull()?.coerceAtLeast(0) ?: 0L
            val end = attr(el, "endTime").toLongOrNull()?.coerceAtLeast(start + 1000L) ?: (start + 5000L)
            val old = slots[ref]
            slots[ref] = if (old == null) MediaSlot(ref, start, end)
                else MediaSlot(ref, minOf(old.startMs, start), maxOf(old.endMs, end))
        }
        return slots.values.toList()
    }

    private fun readAssetText(name: String): String = assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }

    private fun jsonClone(source: JSONObject): JSONObject = JSONObject(source.toString())

    private fun saveConverted(uri: Uri) {
        try {
            val slots = collectMediaSlots()
            require(slots.isNotEmpty() || mediaRefs.isEmpty()) { "Slot foto XML tidak terbaca" }
            require(slots.all { mediaRefs.contains(it.ref) }) { "Daftar media XML berubah. Import ulang XML." }

            val draft = JSONObject(readAssetText("capcut_template.json"))
            val baseTracks = draft.optJSONArray("tracks") ?: JSONArray()
            require(baseTracks.length() > 0) { "Template CapCut tidak lengkap" }
            val baseTrack = jsonClone(baseTracks.getJSONObject(0))
            val baseSegment = baseTrack.getJSONArray("segments").getJSONObject(0)
            val baseMaterial = draft.getJSONObject("materials").getJSONArray("videos").getJSONObject(0)

            val imageMaterials = JSONArray()
            val segments = JSONArray()
            val mediaBytes = linkedMapOf<String, ByteArray>()
            var cursorUs = 0L
            var totalUs = 0L

            slots.forEachIndexed { index, slot ->
                val photoUri = selectedPhotos[index] ?: error("Foto ${index + 1} belum dipilih")
                val bytes = contentResolver.openInputStream(photoUri)?.use { it.readBytes() }
                    ?: error("Foto ${index + 1} tidak dapat dibaca")
                require(bytes.isNotEmpty()) { "Foto ${index + 1} kosong" }
                val ext = when (contentResolver.getType(photoUri)?.lowercase()) {
                    "image/png" -> "png"
                    "image/webp" -> "webp"
                    "image/gif" -> "gif"
                    else -> "jpg"
                }
                val fileName = "photo_${index + 1}.$ext"
                mediaBytes[fileName] = bytes
                val materialId = UUID.randomUUID().toString().uppercase()
                val segmentId = UUID.randomUUID().toString().uppercase()
                val durationUs = ((slot.endMs - slot.startMs).coerceAtLeast(1000L)) * 1000L
                val targetStartUs = slot.startMs * 1000L

                val material = jsonClone(baseMaterial)
                material.put("id", materialId)
                material.put("unique_id", UUID.randomUUID().toString().replace("-", ""))
                material.put("type", "photo")
                material.put("duration", durationUs)
                material.put("path", "media/$fileName")
                material.put("media_path", "media/$fileName")
                material.put("material_name", fileName)
                material.put("has_audio", false)
                material.put("local_material_id", UUID.randomUUID().toString())
                imageMaterials.put(material)

                val segment = jsonClone(baseSegment)
                segment.put("id", segmentId)
                segment.put("material_id", materialId)
                segment.put("source_timerange", JSONObject().put("start", 0).put("duration", durationUs))
                segment.put("target_timerange", JSONObject().put("start", targetStartUs).put("duration", durationUs))
                segment.put("extra_material_refs", JSONArray())
                segment.put("keyframe_refs", JSONArray())
                segment.put("render_index", index)
                segments.put(segment)
                cursorUs = maxOf(cursorUs, targetStartUs + durationUs)
                totalUs = maxOf(totalUs, cursorUs)
            }

            baseTrack.put("id", UUID.randomUUID().toString().uppercase())
            baseTrack.put("segments", segments)
            baseTrack.put("name", "SUJ PROJECT - Media XML")
            val tracks = JSONArray().put(baseTrack)
            draft.put("tracks", tracks)
            draft.put("duration", totalUs)
            draft.put("name", draftName)
            draft.put("id", UUID.randomUUID().toString().uppercase())
            val materials = draft.getJSONObject("materials")
            materials.put("images", imageMaterials)
            materials.put("videos", JSONArray())
            materials.put("audios", JSONArray())
            draft.put("keyframes", JSONObject().put("videos", JSONArray()).put("audios", JSONArray())
                .put("texts", JSONArray()).put("stickers", JSONArray()).put("filters", JSONArray())
                .put("adjusts", JSONArray()).put("handwrites", JSONArray()).put("effects", JSONArray()))

            val timelineId = draft.getString("id")
            val projectInfo = JSONObject(readAssetText("project_template.json"))
            projectInfo.put("id", UUID.randomUUID().toString().uppercase())
            projectInfo.put("main_timeline_id", timelineId)
            val timelineList = projectInfo.optJSONArray("timelines") ?: JSONArray()
            if (timelineList.length() > 0) {
                timelineList.getJSONObject(0).put("id", timelineId)
            }

            val meta = JSONObject(readAssetText("capcut_meta_template.json"))
            meta.put("draft_id", UUID.randomUUID().toString().uppercase())
            meta.put("draft_name", draftName)
            meta.put("draft_fold_path", "")
            meta.put("draft_root_path", "")
            meta.put("draft_materials", JSONArray())
            meta.put("draft_timeline_materials_size_", mediaBytes.values.sumOf { it.size })
            meta.put("tm_duration", totalUs)

            contentResolver.openOutputStream(uri)?.use { raw ->
                ZipOutputStream(raw).use { zip ->
                    fun addText(path: String, text: String) {
                        zip.putNextEntry(ZipEntry("$path"))
                        zip.write(text.toByteArray(Charsets.UTF_8))
                        zip.closeEntry()
                    }
                    val folder = draftName.replace(Regex("[^A-Za-z0-9._ -]"), "_").ifBlank { "SUJ_PROJECT" }
                    val prefix = "$folder/"
                    val timelineFolder = "${prefix}Timelines/$timelineId/"
                    addText(prefix + "draft_content.json", draft.toString(2))
                    addText(prefix + "draft_meta_info.json", meta.toString(2))
                    addText(prefix + "Timelines/project.json", projectInfo.toString(2))
                    addText(timelineFolder + "draft_content.json", draft.toString(2))
                    assets.open("draft_cover.jpg").use { input ->
                        zip.putNextEntry(ZipEntry(prefix + "draft_cover.jpg"))
                        input.copyTo(zip)
                        zip.closeEntry()
                    }
                    mediaBytes.forEach { (name, bytes) ->
                        zip.putNextEntry(ZipEntry(prefix + "media/$name"))
                        zip.write(bytes)
                        zip.closeEntry()
                    }
                    addText(prefix + "README_IMPORT.txt", "SUJ PROJECT - Paket draf CapCut PC\n\nEkstrak folder ini, lalu salin folder '$folder' ke folder draf CapCut PC. Jika CapCut tidak menemukan media, relink foto dari folder media.\n\nCatatan: format proyek dibuat dari template CapCut yang diberikan. Efek dan keyframe khusus Alight Motion belum dikonversi otomatis.\n")
                }
            } ?: error("Tidak dapat membuat file ZIP")

            bottomStatus.text = "Paket proyek CapCut berhasil dibuat: ${mediaBytes.size} foto. Efek/keyframe XML belum diterjemahkan otomatis."
            bottomStatus.setTextColor(green)
            Toast.makeText(this, "Paket proyek CapCut berhasil disimpan", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            bottomStatus.text = "Gagal membuat proyek: ${e.message ?: "kesalahan tidak diketahui"}"
            bottomStatus.setTextColor(Color.RED)
            Toast.makeText(this, "Gagal membuat proyek CapCut", Toast.LENGTH_LONG).show()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

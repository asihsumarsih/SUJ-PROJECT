# SUJ PROJECT – XmlConvert v1.3 (CapCut Draft Bundle)

Versi ini mempertahankan tampilan aplikasi SUJ PROJECT dan menu XmlConvert. Tombol SIMPAN sekarang membuat paket ZIP struktur draf CapCut PC berdasarkan template proyek CapCut yang diberikan pengguna, bukan lagi menyimpan XML hasil edit sebagai dokumen biasa.

## Build APK

Jalankan GitHub Actions workflow `Build SUJ PROJECT APK` (workflow_dispatch) atau push ke branch main/master. Artifact bernama `SUJ-PROJECT-debug-APK`.

## Alur SIMPAN

- XML diparse untuk menemukan slot foto unik pada elemen `<shape fillType="media" fillImage="...">`.
- Pengguna memilih foto pengganti dari galeri sesuai jumlah slot yang terdeteksi.
- SIMPAN membuat ZIP berisi `draft_content.json`, `draft_meta_info.json`, `Timelines/project.json`, salinan timeline, cover, dan folder `media/`.
- Struktur JSON dibuat dari template proyek CapCut PC yang diberikan pengguna (`1121.zip`). Foto disalin ke dalam paket; path media ditulis relatif sebagai `media/photo_N.ext`.
- Ekstrak paket di PC dan salin folder proyek ke folder draf CapCut. Jika CapCut tidak menemukan foto karena versi aplikasi mengharuskan path absolut, lakukan relink media dari folder `media`.

## Batasan yang harus diketahui

- Ini adalah generator paket draf awal berdasarkan template yang tersedia, belum diuji dengan CapCut PC langsung. Kompatibilitas pembukaan paket harus diuji di CapCut PC.
- Template `1121.zip` yang diberikan tidak memiliki material foto, efek, atau keyframe aktif sebagai contoh. Karena itu, efek dan keyframe khusus Alight Motion belum diterjemahkan otomatis ke format CapCut.
- Pemilihan nama draf pada UI adalah nama folder/paket yang dibuat; aplikasi tidak membaca folder privat CapCut secara langsung.
- Slot foto yang dihitung masih dibatasi pada referensi galeri Android `content://media/external/images/` atau `content://media/external/image/` pada elemen `shape` bertipe `media`. Referensi aset internal Alight Motion seperti `am:...jpg` tidak ditimpa.

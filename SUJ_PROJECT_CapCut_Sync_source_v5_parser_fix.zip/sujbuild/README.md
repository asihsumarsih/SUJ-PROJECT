# SUJ PROJECT – XmlConvert v1.2

Versi ini menyederhanakan aplikasi mengikuti alur video tutorial: halaman awal hanya menampilkan menu XmlConvert; halaman berikutnya menampilkan Pilih Proyek (Draf), status XML, IMPORT XML, Media dalam Draf, daftar foto dinamis, serta tombol BATAL dan SIMPAN.

## Build APK

Jalankan GitHub Actions workflow `Build SUJ PROJECT APK` (workflow_dispatch) atau push ke branch main/master. Artifact bernama `SUJ-PROJECT-debug-APK`.

## Catatan fungsi

- XML diparse dan jumlah media dihitung dari elemen `<shape fillType="media" fillImage="...">` yang unik.
- Foto dipilih dari galeri dan URI foto ditulis sebagai nilai `fillImage` pada XML hasil.
- Ini menghasilkan XML dengan referensi URI Android. Kompatibilitas URI tersebut dengan format proyek CapCut belum dibuktikan; keberhasilan menyimpan XML tidak berarti CapCut pasti dapat mengimpor atau membuka proyek.
- Pemilihan nama draf pada UI hanya menyimpan label yang diketik pengguna; aplikasi ini belum membaca folder draf privat CapCut secara langsung.


## Sinkronisasi nama proyek CapCut (uji coba)

- Di halaman XmlConvert, tekan **PILIH FOLDER CAPCUT** dan pilih folder Draft CapCut yang dapat diakses Android.
- Tekan **SINKRONKAN** untuk memindai folder dan subfolder hingga kedalaman 4 tingkat.
- SUJ mencari file `draft_meta_info.json`, `draft_content.json`, atau `draft_info.json`, lalu mencoba membaca nama proyek dari metadata.
- Ketuk nama proyek untuk memilih salah satu proyek yang ditemukan.

**Batasan Android:** beberapa versi Android/CapCut memblokir akses SAF ke `Android/data` atau folder privat CapCut. Jika pemilih folder tidak mengizinkan folder Draft dipilih, atau metadata tidak tersedia, SUJ tidak dapat membaca daftar tersebut secara otomatis. Fitur ini tidak mengubah atau menulis proyek CapCut.


## Perbaikan v1.3
- Parser XML tidak lagi mewajibkan fitur Apache `disallow-doctype-decl` yang tidak tersedia pada sebagian parser Android.
- Fitur eksternal XML dinonaktifkan secara defensif; fitur parser opsional yang tidak didukung tidak menggagalkan impor.
- Perbaikan ini mengatasi kegagalan saat MEMBACA XML. Kode saat ini masih mengekspor XML Alight Motion yang media-nya diganti; ini belum merupakan konverter struktur proyek Alight Motion menjadi format proyek CapCut. Untuk konversi penuh diperlukan contoh file proyek CapCut hasil ekspor beserta XML AM sumber untuk memetakan struktur timeline, efek, keyframe, dan media.

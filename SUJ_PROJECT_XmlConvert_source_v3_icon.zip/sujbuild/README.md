# SUJ PROJECT – XmlConvert v1.2

Versi ini menyederhanakan aplikasi mengikuti alur video tutorial: halaman awal hanya menampilkan menu XmlConvert; halaman berikutnya menampilkan Pilih Proyek (Draf), status XML, IMPORT XML, Media dalam Draf, daftar foto dinamis, serta tombol BATAL dan SIMPAN.

## Build APK

Jalankan GitHub Actions workflow `Build SUJ PROJECT APK` (workflow_dispatch) atau push ke branch main/master. Artifact bernama `SUJ-PROJECT-debug-APK`.

## Catatan fungsi

- XML diparse dan jumlah media dihitung dari elemen `<shape fillType="media" fillImage="...">` yang unik.
- Foto dipilih dari galeri dan URI foto ditulis sebagai nilai `fillImage` pada XML hasil.
- Ini menghasilkan XML dengan referensi URI Android. Kompatibilitas URI tersebut dengan format proyek CapCut belum dibuktikan; keberhasilan menyimpan XML tidak berarti CapCut pasti dapat mengimpor atau membuka proyek.
- Pemilihan nama draf pada UI hanya menyimpan label yang diketik pengguna; aplikasi ini belum membaca folder draf privat CapCut secara langsung.

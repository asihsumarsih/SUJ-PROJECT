# SUJ PROJECT — V9 translator patch

This source keeps the existing SUJ PROJECT UI and Save/export flow. The patch is limited to XML translation:

- Keeps independent Scale X and Scale Y keyframe groups.
- Preserves the XML keyframe list (including its easing metadata) and emits Bezier curve data for cubic-Bezier and approximate elastic easing.
- Stops falsely translating Alight Motion Swing, Oscillate, and Flip3 into CapCut's Jitter Blur effect. These motion effects do not have a verified one-to-one equivalent in the current CapCut base template, so they are not replaced with an unrelated blur effect.
- Keeps Motion Blur mapped separately from Swing/Oscillate/Flip3.

Important: CapCut and Alight Motion use different effect systems. This patch prevents known incorrect mappings, but exact visual parity is not guaranteed. The generated project must be opened and tested in CapCut. A Gradle build has not been run in this environment; use the included GitHub Actions workflow to build the APK.

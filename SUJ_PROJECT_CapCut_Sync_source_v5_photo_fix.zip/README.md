# SUJ PROJECT – XmlConvert v1.2

Versi ini menyederhanakan aplikasi mengikuti alur video tutorial: halaman awal hanya menampilkan menu XmlConvert; halaman berikutnya menampilkan Pilih Proyek (Draf), status XML, IMPORT XML, Media dalam Draf, daftar foto dinamis, serta tombol BATAL dan SIMPAN.

## Build APK

Jalankan GitHub Actions workflow `Build SUJ PROJECT APK` (workflow_dispatch) atau push ke branch main/master. Artifact bernama `SUJ-PROJECT-debug-APK`.

## Catatan fungsi

- XML diparse dan slot foto dihitung dari referensi foto Galeri Android yang unik. Referensi internal `am:...` tidak ditampilkan sebagai slot foto dan tidak diubah.
- Foto dipilih dari galeri dan URI foto ditulis sebagai nilai `fillImage` pada XML hasil.
- Ini menghasilkan XML dengan referensi URI Android. Kompatibilitas URI tersebut dengan format proyek CapCut belum dibuktikan; keberhasilan menyimpan XML tidak berarti CapCut pasti dapat mengimpor atau membuka proyek.
- Nama proyek diambil dari metadata draf CapCut yang terbaca setelah folder Draft dipilih dan disinkronkan. Jika Android/CapCut memblokir folder privat, nama proyek tidak dapat disinkronkan otomatis.


## Sinkronisasi nama proyek CapCut (uji coba)

- Di halaman XmlConvert, tekan **PILIH FOLDER CAPCUT** dan pilih folder Draft CapCut yang dapat diakses Android.
- Tekan **SINKRONKAN** untuk memindai folder dan subfolder hingga kedalaman 4 tingkat.
- SUJ mencari file `draft_meta_info.json`, `draft_content.json`, atau `draft_info.json`, lalu mencoba membaca nama proyek dari metadata.
- Ketuk nama proyek untuk memilih salah satu proyek yang ditemukan.

**Batasan Android:** beberapa versi Android/CapCut memblokir akses SAF ke `Android/data` atau folder privat CapCut. Jika pemilih folder tidak mengizinkan folder Draft dipilih, atau metadata tidak tersedia, SUJ tidak dapat membaca daftar tersebut secara otomatis. Fitur ini tidak mengubah atau menulis proyek CapCut.


## Perbaikan berdasarkan screenshot 15 Nov 2026

- Nama XML dibaca dari `OpenableColumns.DISPLAY_NAME`, bukan ID dokumen seperti `document:1000032683`; format status tetap `primary:<nama-file.xml>`.
- XML contoh `tie me down kaweni meri (anxicuy)` memiliki tiga referensi foto Galeri (`content://media/external/images/...`) dan satu referensi internal `am:...jpg`. Hanya tiga foto Galeri yang ditampilkan sebagai slot pilih foto.
- Tombol SIMPAN pada versi ini tetap mengekspor XML hasil penggantian foto. Versi ini belum menulis format database/draft privat CapCut, jadi tidak menampilkan klaim palsu bahwa proyek sudah disuntikkan ke CapCut.

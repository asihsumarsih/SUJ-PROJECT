package com.sujproject.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.xml.sax.InputSource
import java.io.StringReader
import java.io.StringWriter
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

class MainActivity : ComponentActivity() {
    private val black = Color.rgb(12, 12, 12)
    private val card = Color.rgb(35, 35, 35)
    private val purple = Color.rgb(174, 0, 220)
    private val green = Color.rgb(50, 220, 95)
    private val white = Color.WHITE

    private var xmlText = ""
    private var xmlName = ""
    private var draftName = "Pilih folder Draft CapCut"
    private var capcutTreeUri: Uri? = null
    private var capcutProjects = mutableListOf<String>()
    private var projectPickerHint = "Folder Draft CapCut belum dipilih"
    private var mediaRefs = mutableListOf<String>()
    private var selectedPhotos = mutableMapOf<Int, Uri>()
    private lateinit var page: LinearLayout
    private lateinit var xmlStatus: TextView
    private lateinit var mediaArea: LinearLayout
    private lateinit var bottomStatus: TextView

    private val importXml = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            try {
                xmlText = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("File tidak dapat dibaca")
                val parsed = parseMedia(xmlText)
                mediaRefs = parsed.toMutableList()
                selectedPhotos.clear()
                xmlName = queryDisplayName(uri)
                if (xmlName.isBlank()) xmlName = uri.lastPathSegment?.substringAfterLast('/') ?: "Proyek.xml"
                renderConverter()
                xmlStatus.text = "● primary:$xmlName"
                xmlStatus.setTextColor(green)
                bottomStatus.text = "Terdeteksi ${mediaRefs.size} foto di XML. Silakan pilih foto pengganti."
                bottomStatus.setTextColor(green)
            } catch (e: Exception) {
                xmlText = ""
                mediaRefs.clear()
                renderConverter()
                xmlStatus.text = "● XML gagal dimuat: ${e.message ?: "format tidak dikenali"}"
                xmlStatus.setTextColor(Color.RED)
            }
        }
    }

    private var pickingIndex = -1
    private val pickPhoto = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && pickingIndex >= 0) {
            try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            selectedPhotos[pickingIndex] = uri
            renderMediaRows()
            bottomStatus.text = "Foto ${pickingIndex + 1} berhasil dipilih."
            bottomStatus.setTextColor(green)
        }
    }

    private val pickCapCutFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                contentResolver.takePersistableUriPermission(uri, flags)
            } catch (_: Exception) { }
            capcutTreeUri = uri
            scanCapCutProjects()
            renderConverter()
        }
    }

    private val saveXml = registerForActivityResult(ActivityResultContracts.CreateDocument("application/xml")) { uri ->
        if (uri != null) saveConverted(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        showHome()
    }

    private fun showHome() {
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(24), dp(30), dp(24), dp(24))
        }
        val title = TextView(this).apply {
            text = "SUJ PROJECT"
            textSize = 28f
            setTextColor(Color.BLACK)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(10), 0, dp(38))
        }
        root.addView(title)
        val menu = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val icon = TextView(this).apply {
            text = "↕"
            textSize = 48f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        val label = TextView(this).apply {
            text = "XmlConvert"
            textSize = 14f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        menu.addView(icon, LinearLayout.LayoutParams(dp(110), dp(68)))
        menu.addView(label, LinearLayout.LayoutParams(dp(110), dp(30)))
        menu.setOnClickListener { renderConverter() }
        root.addView(menu, LinearLayout.LayoutParams(dp(130), dp(110)))
        setContentView(root)
    }

    private fun renderConverter() {
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(black) }
        val scroll = ScrollView(this)
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(black)
            setPadding(dp(18), dp(24), dp(18), dp(12))
        }
        val projectLabel = TextView(this).apply {
            text = "PILIH PROYEK (DRAF)"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(20))
        }
        page.addView(projectLabel)
        val project = TextView(this).apply {
            text = draftName + "   ▾"
            textSize = 16f
            setTextColor(white)
            setPadding(dp(8), dp(8), dp(8), dp(12))
            setOnClickListener { showProjectChooser() }
        }
        page.addView(project)
        val syncRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val chooseFolder = actionButton("PILIH FOLDER CAPCUT", card) {
            pickCapCutFolder.launch(capcutTreeUri)
        }
        chooseFolder.textSize = 11f
        syncRow.addView(chooseFolder, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
        val refresh = actionButton("SINKRONKAN", Color.rgb(65,65,65)) {
            scanCapCutProjects()
            renderConverter()
        }
        refresh.textSize = 11f
        syncRow.addView(refresh, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) })
        page.addView(syncRow)
        val folderInfo = TextView(this).apply {
            text = projectPickerHint
            textSize = 10f
            setTextColor(Color.GRAY)
            setPadding(dp(4), dp(6), dp(4), dp(8))
        }
        page.addView(folderInfo)
        xmlStatus = TextView(this).apply {
            text = if (xmlText.isBlank()) "● XML Belum Dimuat" else "● primary:$xmlName"
            textSize = 14f
            setTextColor(if (xmlText.isBlank()) Color.rgb(240, 75, 115) else green)
            setPadding(0, dp(8), 0, dp(16))
        }
        page.addView(xmlStatus)
        val import = TextView(this).apply {
            text = "IMPORT XML"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(white)
            setBackgroundColor(card)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { importXml.launch(arrayOf("application/xml", "text/xml", "application/*", "*/*")) }
        }
        page.addView(import, LinearLayout.LayoutParams(-1, dp(48)))
        val mediaTitle = TextView(this).apply {
            text = "Media dalam Draf"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(white)
            setPadding(0, dp(32), 0, dp(24))
        }
        page.addView(mediaTitle)
        mediaArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(mediaArea)
        bottomStatus = TextView(this).apply {
            text = if (mediaRefs.isEmpty()) "Menunggu perintah..." else "Terdeteksi ${mediaRefs.size} foto di XML. Silakan pilih foto pengganti."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
            setPadding(dp(4), dp(18), dp(4), dp(14))
        }
        page.addView(bottomStatus)
        scroll.addView(page)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(8), dp(14), dp(12))
            setBackgroundColor(black)
        }
        val cancel = actionButton("BATAL", Color.rgb(65,65,65)) { showHome() }
        val save = actionButton("SIMPAN", purple) {
            if (xmlText.isBlank()) Toast.makeText(this, "Import XML terlebih dahulu", Toast.LENGTH_SHORT).show()
            else if (mediaRefs.isNotEmpty() && selectedPhotos.size < mediaRefs.size) {
                bottomStatus.text = "Pilih semua ${mediaRefs.size} foto terlebih dahulu."
                bottomStatus.setTextColor(Color.RED)
            } else saveXml.launch((xmlName.substringBeforeLast('.', xmlName)).ifBlank { "XmlConvert" } + "_converted.xml")
        }
        buttons.addView(cancel, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(8) })
        buttons.addView(save, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(8) })
        outer.addView(buttons)
        setContentView(outer)
        renderMediaRows()
    }

    private fun showProjectChooser() {
        if (capcutProjects.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Proyek CapCut belum ditemukan")
                .setMessage("Pilih folder Draft CapCut terlebih dahulu, lalu tekan SINKRONKAN. Jika Android tidak mengizinkan akses folder tersebut, daftar otomatis tidak dapat dibaca.")
                .setPositiveButton("PILIH FOLDER") { _, _ -> pickCapCutFolder.launch(capcutTreeUri) }
                .setNegativeButton("TUTUP", null).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Pilih Proyek (Draf)")
            .setItems(capcutProjects.toTypedArray()) { _, which ->
                draftName = capcutProjects[which]
                renderConverter()
            }
            .setNeutralButton("SINKRONKAN") { _, _ -> scanCapCutProjects(); renderConverter() }
            .setNegativeButton("TUTUP", null).show()
    }

    private fun scanCapCutProjects() {
        val treeUri = capcutTreeUri
        if (treeUri == null) {
            projectPickerHint = "Folder Draft CapCut belum dipilih"
            capcutProjects.clear()
            return
        }
        try {
            val root = DocumentFile.fromTreeUri(this, treeUri)
                ?: error("Folder tidak dapat dibuka")
            val found = linkedSetOf<String>()
            fun visit(dir: DocumentFile, depth: Int) {
                if (depth > 4 || !dir.isDirectory) return
                val children = try { dir.listFiles() } catch (_: Exception) { emptyArray() }
                val names = children.filter { it.isFile }.map { it.name.orEmpty() }
                val meta = children.firstOrNull {
                    it.isFile && (it.name.equals("draft_meta_info.json", true) ||
                        it.name.equals("draft_content.json", true) ||
                        it.name.equals("draft_info.json", true))
                }
                if (meta != null) {
                    val parsedName = readDraftDisplayName(meta.uri)
                    val candidate = parsedName.ifBlank { dir.name.orEmpty() }
                    if (candidate.isNotBlank() && candidate != "files") found.add(candidate)
                }
                children.filter { it.isDirectory }.forEach { visit(it, depth + 1) }
            }
            visit(root, 0)
            capcutProjects = found.toMutableList()
            projectPickerHint = if (found.isEmpty())
                "Folder terbaca, tetapi file metadata proyek CapCut tidak ditemukan."
            else "Ditemukan ${found.size} proyek CapCut."
            if (draftName !in capcutProjects && capcutProjects.isNotEmpty()) draftName = capcutProjects.first()
        } catch (e: Exception) {
            capcutProjects.clear()
            projectPickerHint = "Gagal membaca folder: ${e.message ?: "izin tidak tersedia"}"
        }
    }

    private fun readDraftDisplayName(uri: Uri): String {
        return try {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: return ""
            val json = JSONObject(raw)
            val keys = listOf("draft_name", "draftName", "name", "title")
            for (key in keys) {
                val value = json.optString(key, "")
                if (value.isNotBlank() && value != "null") return value
            }
            ""
        } catch (_: Exception) { "" }
    }

    private fun renderMediaRows() {
        if (!::mediaArea.isInitialized) return
        mediaArea.removeAllViews()
        if (mediaRefs.isEmpty()) return
        val ranges = findRanges(xmlText, mediaRefs.size)
        val hint = TextView(this).apply {
            text = "Diperlukan ${mediaRefs.size} Foto (Klik untuk ganti dari Galeri)"
            textSize = 13f
            setTextColor(purple)
            setPadding(0, 0, 0, dp(12))
        }
        mediaArea.addView(hint)
        mediaRefs.forEachIndexed { index, ref ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
                setBackgroundColor(Color.rgb(27,27,27))
            }
            val thumb = TextView(this).apply {
                text = if (selectedPhotos.containsKey(index)) "✓" else "▧"
                textSize = 25f
                gravity = Gravity.CENTER
                setTextColor(if (selectedPhotos.containsKey(index)) green else Color.GRAY)
                setBackgroundColor(card)
            }
            row.addView(thumb, LinearLayout.LayoutParams(dp(66), dp(66)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(6), 0) }
            val title = TextView(this).apply { text = "Foto ${index + 1}  (${ranges.getOrNull(index) ?: "Media XML"})"; textSize = 14f; setTextColor(white) }
            val sub = TextView(this).apply {
                text = "Asli: ${ref.take(34)}${if (ref.length > 34) "..." else ""}"
                textSize = 10f; setTextColor(Color.LTGRAY); setPadding(0, dp(4), 0, 0)
            }
            info.addView(title); info.addView(sub)
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val choose = TextView(this).apply {
                text = if (selectedPhotos.containsKey(index)) "GANTI" else "PILIH"
                textSize = 12f; gravity = Gravity.CENTER; setTextColor(white); setBackgroundColor(Color.rgb(116, 0, 150)); setPadding(dp(12), dp(12), dp(12), dp(12))
                setOnClickListener { pickingIndex = index; pickPhoto.launch(arrayOf("image/*")) }
            }
            row.addView(choose, LinearLayout.LayoutParams(dp(68), dp(42)))
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            mediaArea.addView(row, lp)
        }
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 16f; gravity = Gravity.CENTER; setTextColor(white); setBackgroundColor(color)
        setOnClickListener { click() }
    }

    // Only count actual Android gallery image references as replaceable photos.
    // Alight Motion internal references such as "am:...jpg" are project assets,
    // not gallery photo slots, and must remain untouched.
    private fun isReplaceablePhotoReference(value: String): Boolean {
        val v = value.trim().lowercase()
        return v.startsWith("content://media/external/images/") ||
            v.startsWith("content://media/external/image/")
    }

    private fun parseMedia(source: String): List<String> {
        require(source.isNotBlank()) { "File XML kosong" }
        val doc = parseDocument(source)
        val found = linkedSetOf<String>()
        val nodes = doc.getElementsByTagName("shape")
        for (i in 0 until nodes.length) {
            val el = nodes.item(i) as? Element ?: continue
            if (el.getAttribute("fillType").equals("media", ignoreCase = true)) {
                val value = el.getAttribute("fillImage").ifBlank { el.getAttribute("media") }
                if (isReplaceablePhotoReference(value)) found.add(value)
            }
        }
        return found.toList()
    }

    private fun parseDocument(source: String): Document {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            setFeature("http://xml.org/sax/features/external-general-entities", false)
            setFeature("http://xml.org/sax/features/external-parameter-entities", false)
            setExpandEntityReferences(false)
        }
        val builder = factory.newDocumentBuilder()
        builder.setEntityResolver { _, _ -> InputSource(StringReader("")) }
        return builder.parse(InputSource(StringReader(source)))
    }

    private fun findRanges(source: String, count: Int): List<String> {
        val doc = try { parseDocument(source) } catch (_: Exception) { return emptyList() }
        val result = linkedMapOf<String, String>()
        val nodes = doc.getElementsByTagName("shape")
        for (i in 0 until nodes.length) {
            val el = nodes.item(i) as? Element ?: continue
            if (!el.getAttribute("fillType").equals("media", ignoreCase = true)) continue
            val value = el.getAttribute("fillImage").ifBlank { el.getAttribute("media") }
            if (!isReplaceablePhotoReference(value) || value in result) continue
            val start = el.getAttribute("startTime").toLongOrNull()
            val end = el.getAttribute("endTime").toLongOrNull()
            result[value] = if (start != null && end != null)
                "%.2fs - %.2fs".format(start / 1000.0, end / 1000.0) else "Media XML"
        }
        return result.values.take(count)
    }

    private fun queryDisplayName(uri: Uri): String {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) cursor.getString(index).orEmpty() else ""
                } else ""
            } ?: ""
        } catch (_: Exception) { "" }
    }

    private fun saveConverted(uri: Uri) {
        try {
            val doc = parseDocument(xmlText)
            val nodes = doc.getElementsByTagName("shape")
            val replaced = mutableSetOf<String>()
            for (i in 0 until nodes.length) {
                val el = nodes.item(i) as? Element ?: continue
                if (el.getAttribute("fillType") != "media") continue
                val old = el.getAttribute("fillImage")
                val index = mediaRefs.indexOf(old)
                if (index >= 0 && selectedPhotos[index] != null) {
                    // Keep the replacement URI as the new media source in the exported XML.
                    el.setAttribute("fillImage", selectedPhotos[index].toString())
                    replaced.add(old)
                }
            }
            val tf = TransformerFactory.newInstance()
            val transformer = tf.newTransformer().apply {
                setOutputProperty(OutputKeys.ENCODING, "UTF-8")
                setOutputProperty(OutputKeys.INDENT, "yes")
                setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no")
            }
            val out = StringWriter()
            transformer.transform(DOMSource(doc), StreamResult(out))
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(out.toString()) }
                ?: error("Tidak dapat menyimpan file")
            bottomStatus.text = "XML berhasil disimpan. Foto yang diganti: ${replaced.size}. Belum disuntikkan langsung ke CapCut."
            bottomStatus.setTextColor(green)
            Toast.makeText(this, "XML berhasil disimpan", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            bottomStatus.text = "Gagal menyimpan: ${e.message}"
            bottomStatus.setTextColor(Color.RED)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

# SUJ PROJECT

Android XML project toolkit built with Kotlin.

## Current features
- Import XML documents through Android's document picker.
- Validate XML with external DTD/entities disabled.
- Inspect common Alight Motion scene fields (root, duration, FPS, shape/effect counts and media layers).
- Format XML for easier reading while retaining XML element/attribute values and comments supported by the parser.
- Edit XML in the built-in text editor and export it as an XML file.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact.

## Important scope
The Convert / Format action validates and pretty-prints XML. It does not convert an arbitrary XML document into a different application-specific project format, and it does not guarantee that an imported project will work in Alight Motion. Test exported projects in the target application before relying on them.

## Build
Run `gradle --no-daemon :app:assembleDebug` with JDK 17 and Android SDK platform 35 installed.

package com.sujproject.app

import androidx.activity.ComponentActivity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private val bg = Color.rgb(16, 9, 28)
    private val panel = Color.rgb(35, 22, 54)
    private val neon = Color.rgb(199, 125, 255)
    private val white = Color.WHITE
    private var projectText = """<?xml version="1.0" encoding="UTF-8"?>
<project name="SUJ PROJECT">
    <description>Template XML contoh</description>
</project>"""
    private var selectedPhoto: Uri? = null
    private lateinit var status: TextView
    private lateinit var photo: ImageView

    private val importXml = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            try {
                contentResolver.openInputStream(it)?.bufferedReader()?.use { reader ->
                    projectText = reader.readText()
                }
                status.text = "XML dimuat: ${it.lastPathSegment ?: "file XML"}"
                toast("File XML berhasil diimpor")
            } catch (e: Exception) {
                toast("Gagal membaca XML: ${e.message}")
            }
        }
    }
    private val choosePhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            selectedPhoto = it
            photo.setImageURI(it)
            photo.visibility = View.VISIBLE
            status.text = "Foto dipilih dari galeri"
        }
    }
    private val exportXml = registerForActivityResult(ActivityResultContracts.CreateDocument("application/xml")) { uri ->
        uri?.let {
            try {
                contentResolver.openOutputStream(it)?.bufferedWriter()?.use { writer -> writer.write(projectText) }
                toast("Proyek berhasil diekspor")
                status.text = "Ekspor selesai"
            } catch (e: Exception) {
                toast("Gagal mengekspor: ${e.message}")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(20), dp(24), dp(20), dp(20))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val brand = TextView(this).apply {
            text = "SUJ PROJECT"
            textSize = 30f
            setTextColor(neon)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            letterSpacing = 0.08f
        }
        content.addView(brand, matchWrap())
        val subtitle = TextView(this).apply {
            text = "XML TEMPLATE • PROJECT MANAGER"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(22))
            letterSpacing = 0.12f
        }
        content.addView(subtitle, matchWrap())
        val intro = TextView(this).apply {
            text = "Selamat datang! Kelola template dan proyek XML kamu dalam satu aplikasi."
            textSize = 15f
            setTextColor(white)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        content.addView(intro, matchWrap())
        content.addView(section("FITUR UTAMA"), matchWrap())
        addAction(content, "▤  Template XML", "Lihat template contoh yang tersedia") {
            status.text = "Template: Template Dasar SUJ"
            projectText = """<?xml version="1.0" encoding="UTF-8"?>
<project name="SUJ PROJECT">
    <template>Template Dasar SUJ</template>
    <description>Ganti isi ini dengan struktur XML proyek yang sesuai.</description>
</project>"""
            toast("Template dasar dimuat")
        }
        addAction(content, "⇧  Import XML", "Pilih file XML dari penyimpanan") {
            importXml.launch(arrayOf("text/*", "application/xml", "application/octet-stream"))
        }
        addAction(content, "▧  Galeri Foto", "Pilih foto untuk referensi proyek") {
            choosePhoto.launch("image/*")
        }
        addAction(content, "⇩  Export Proyek", "Simpan proyek sebagai file XML") {
            exportXml.launch("SUJ_PROJECT.xml")
        }
        photo = ImageView(this).apply {
            visibility = View.GONE
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(0, dp(12), 0, dp(12))
        }
        content.addView(photo, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(190)))
        status = TextView(this).apply {
            text = "Status: Siap digunakan"
            textSize = 13f
            setTextColor(neon)
            setPadding(dp(4), dp(16), dp(4), dp(8))
        }
        content.addView(status, matchWrap())
        val footer = TextView(this).apply {
            text = "SUJ PROJECT  •  Versi 1.0"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(12))
        }
        content.addView(footer, matchWrap())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun section(label: String) = TextView(this).apply {
        text = label
        textSize = 12f
        setTextColor(neon)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(2, dp(24), 2, dp(10))
        letterSpacing = 0.12f
    }

    private fun addAction(parent: LinearLayout, title: String, detail: String, action: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(panel)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 17f
            setTextColor(white)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val desc = TextView(this).apply {
            text = detail
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(5), 0, 0)
        }
        card.addView(heading, matchWrap())
        card.addView(desc, matchWrap())
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(10)
        parent.addView(card, lp)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchParent() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
}

# SUJ PROJECT – XmlConvert v1.4 (CapCut PC Draft Bundle)

Versi ini mempertahankan UI SUJ PROJECT dan menu XmlConvert. Tombol SIMPAN membuat paket proyek CapCut PC menggunakan arsip proyek contoh `1121.zip` yang diberikan pengguna.

## Perubahan utama
- Menggunakan `draft_content.json`, `draft_meta_info.json`, `Timelines/project.json`, dan file pendukung dari arsip proyek CapCut PC contoh.
- Menambahkan foto pilihan sebagai material dan segmen pada track video.
- Mempertahankan track audio/beat, material audio/video, keyframes, beat metadata, dan file pendukung template yang sebelumnya terhapus oleh versi v5.
- Menghasilkan ZIP dengan struktur proyek lengkap dan menampilkan pesan `Beat & foto berhasil disuntikan` setelah ZIP berhasil ditulis.

## Build APK
Jalankan GitHub Actions workflow `Build SUJ PROJECT APK` pada branch utama.

## Batasan penting
- Pesan sukses berarti paket proyek berhasil dibuat di perangkat, bukan berarti CapCut PC sudah otomatis menerima atau membuka proyek. ZIP harus dipindahkan ke PC dan diuji di CapCut PC.
- Track audio/beat dipertahankan dari proyek contoh. Arsip contoh tidak menyertakan file MP4 sumber yang dirujuk oleh path Windows, sehingga audio mungkin perlu ditautkan ulang jika file sumber tidak ada pada PC.
- Animasi/keyframe khusus Alight Motion belum diterjemahkan otomatis ke format keyframe CapCut.
- Path foto di dalam JSON masih relatif terhadap folder proyek; jika CapCut meminta media, lakukan relink ke folder `media`.


## V9 translator refinement

- Improves Alight Motion transform keyframe conversion (position uses source canvas dimensions; scale, rotation and opacity remain separate CapCut keyframe properties).
- Preserves normalized keyframe timing and uses seconds when the source time range fits the clip duration; otherwise it proportionally maps the source keyframe span into the clip.
- Transfers cubicBezier control points into CapCut keyframe controls where available.
- Expands approximate mappings for selected Alight Motion effects to the effects already present in the bundled CapCut template. Unsupported effects still cannot be recreated exactly and are skipped.
- The Save action and ZIP/folder export flow are intentionally unchanged in this revision.

## XML translator revision (photo transform + effect approximation)
- Imports static Alight Motion location, scale, rotation, and opacity values into the CapCut clip transform, in addition to animated keyframes.
- Normalizes several mapped effect parameters to the slider ranges used by the bundled CapCut effect templates.
- Adds approximate mappings for stretch and RGB split effects where the base CapCut project has a close effect template.
- Effect tracks now receive increasing render indices so their ordering is retained more consistently.
- This is an approximation: effects without a compatible template or parameter mapping are not recreated exactly. Build and test in CapCut PC are still required.

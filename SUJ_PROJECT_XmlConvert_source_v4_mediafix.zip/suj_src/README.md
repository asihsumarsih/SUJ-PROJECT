# SUJ PROJECT – XmlConvert v1.2

Versi ini menyederhanakan aplikasi mengikuti alur video tutorial: halaman awal hanya menampilkan menu XmlConvert; halaman berikutnya menampilkan Pilih Proyek (Draf), status XML, IMPORT XML, Media dalam Draf, daftar foto dinamis, serta tombol BATAL dan SIMPAN.

## Build APK

Jalankan GitHub Actions workflow `Build SUJ PROJECT APK` (workflow_dispatch) atau push ke branch main/master. Artifact bernama `SUJ-PROJECT-debug-APK`.

## Catatan fungsi

- XML diparse dan jumlah media dihitung dari elemen `<shape fillType="media" fillImage="...">` yang unik.
- Foto dipilih dari galeri dan URI foto ditulis sebagai nilai `fillImage` pada XML hasil.
- Ini menghasilkan XML dengan referensi URI Android. Kompatibilitas URI tersebut dengan format proyek CapCut belum dibuktikan; keberhasilan menyimpan XML tidak berarti CapCut pasti dapat mengimpor atau membuka proyek.
- Pemilihan nama draf pada UI hanya menyimpan label yang diketik pengguna; aplikasi ini belum membaca folder draf privat CapCut secara langsung.

## Perbaikan parser media (uji AM 16 November 2026)

- Slot foto yang ditampilkan/diganti hanya referensi galeri Android `content://media/external/images/` atau `content://media/external/image/` pada elemen `shape` bertipe `media`.
- Referensi aset internal Alight Motion seperti `am:...jpg` tidak dihitung sebagai foto galeri dan tidak ditimpa.
- Rentang waktu ditampilkan per referensi foto dengan menggabungkan rentang shape yang memakai referensi sama.
- Pesan setelah SIMPAN menjelaskan bahwa hasilnya masih XML hasil penggantian referensi foto, bukan draf CapCut.

Catatan: perbaikan ini memperbaiki penghitungan/penggantian media pada XML AM. Belum ada implementasi atau verifikasi pembuatan draf native CapCut.

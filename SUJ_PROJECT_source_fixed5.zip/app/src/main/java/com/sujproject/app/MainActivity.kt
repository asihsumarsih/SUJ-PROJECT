package com.sujproject.app

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.w3c.dom.Document
import org.xml.sax.InputSource
import java.io.StringReader
import java.io.StringWriter
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

class MainActivity : ComponentActivity() {
    private val background = Color.rgb(16, 9, 28)
    private val panel = Color.rgb(35, 22, 54)
    private val accent = Color.rgb(199, 125, 255)
    private lateinit var editor: EditText
    private lateinit var status: TextView
    private var currentFileName = "SUJ_PROJECT.xml"

    private val importXml = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) readXml(uri)
    }

    private val exportXml = registerForActivityResult(ActivityResultContracts.CreateDocument("application/xml")) { uri ->
        if (uri != null) writeXml(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = background
        window.navigationBarColor = background
        buildScreen()
        validateAndReport()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
            setPadding(dp(16), dp(18), dp(16), dp(12))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "SUJ PROJECT"
            textSize = 28f
            setTextColor(accent)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            letterSpacing = 0.07f
        }
        content.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "XML PROJECT TOOLKIT"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(16))
            letterSpacing = 0.12f
        }
        content.addView(subtitle, matchWrap())

        val intro = TextView(this).apply {
            text = "Impor, periksa, edit, format, dan ekspor file XML. File asli tidak diubah sampai kamu menekan Ekspor."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
        }
        content.addView(intro, matchWrap())

        addSection(content, "FILE XML")
        addButton(content, "Import XML", "Buka file XML dari penyimpanan") {
            importXml.launch(arrayOf("application/xml", "text/xml", "application/*", "text/*", "*/*"))
        }
        addButton(content, "Convert / Format XML", "Periksa XML dan rapikan indentasi tanpa mengubah nilai atribut") {
            convertXml()
        }
        addButton(content, "Export XML", "Simpan hasil edit sebagai file XML") {
            exportXml.launch(currentFileName.ifBlank { "SUJ_PROJECT.xml" })
        }

        addSection(content, "EDITOR XML")
        editor = EditText(this).apply {
            setTextColor(Color.rgb(240, 232, 248))
            setHintTextColor(Color.GRAY)
            hint = "Impor file XML atau tempel XML di sini..."
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(24, 17, 35))
            minLines = 12
            isVerticalScrollBarEnabled = true
            setHorizontallyScrolling(true)
            setText(defaultXml())
        }
        content.addView(editor, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(300)))

        addSection(content, "HASIL PEMERIKSAAN")
        status = TextView(this).apply {
            text = "Status: Siap"
            textSize = 13f
            setTextColor(accent)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        content.addView(status, matchWrap())

        val footer = TextView(this).apply {
            text = "SUJ PROJECT • XML Toolkit"
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(10))
        }
        content.addView(footer, matchWrap())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun defaultXml() = """<?xml version="1.0" encoding="UTF-8"?>
<project name="SUJ PROJECT">
    <description>Impor XML proyek untuk mulai mengedit.</description>
</project>"""

    private fun readXml(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: error("File tidak dapat dibaca")
            inspectXml(text)
            editor.setText(text)
            currentFileName = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.endsWith(".xml", true) }
                ?: "SUJ_PROJECT.xml"
            validateAndReport()
            toast("XML berhasil diimpor")
        } catch (e: Exception) {
            showError("Gagal mengimpor XML", e)
        }
    }

    private fun writeXml(uri: Uri) {
        try {
            val text = editor.text.toString()
            inspectXml(text)
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(text) }
                ?: error("Lokasi penyimpanan tidak tersedia")
            status.text = "Ekspor selesai • ${text.toByteArray(Charsets.UTF_8).size} byte"
            toast("XML berhasil diekspor")
        } catch (e: Exception) {
            showError("Gagal mengekspor XML", e)
        }
    }

    private fun convertXml() {
        try {
            val source = editor.text.toString()
            val report = inspectXml(source)
            val formatted = formatXml(source)
            editor.setText(formatted)
            status.text = report.toStatus() + "\nFormat XML berhasil dirapikan."
            toast("XML valid dan berhasil diformat")
        } catch (e: Exception) {
            showError("XML belum dapat dikonversi", e)
        }
    }

    private data class XmlReport(
        val root: String,
        val shapes: Int,
        val effects: Int,
        val images: Int,
        val textLayers: Int,
        val duration: String,
        val fps: String
    ) {
        fun toStatus(): String = "XML VALID\nRoot: $root\nShape: $shapes • Effect: $effects\nMedia: $images • Text: $textLayers\nDurasi: $duration • FPS: $fps"
    }

    private fun inspectXml(source: String): XmlReport {
        require(source.isNotBlank()) { "Isi XML masih kosong" }
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            setFeature("http://xml.org/sax/features/external-general-entities", false)
            setFeature("http://xml.org/sax/features/external-parameter-entities", false)
            setExpandEntityReferences(false)
        }
        val builder = factory.newDocumentBuilder()
        builder.setEntityResolver { _, _ -> InputSource(StringReader("")) }
        val doc: Document = builder.parse(InputSource(StringReader(source)))
        val root = doc.documentElement ?: error("Elemen root tidak ditemukan")
        val shapes = doc.getElementsByTagName("shape").length
        val effects = doc.getElementsByTagName("effect").length
        val images = doc.getElementsByTagName("shape").let { nodes ->
            (0 until nodes.length).count { i ->
                val node = nodes.item(i)
                node.attributes?.getNamedItem("fillType")?.nodeValue == "media"
            }
        }
        val textLayers = doc.getElementsByTagName("text").length
        val totalTime = root.getAttribute("totalTime").toLongOrNull()
        val duration = totalTime?.let { "%.2f dtk".format(it / 1000.0) } ?: "tidak tersedia"
        val fps = root.getAttribute("fps").ifBlank { "tidak tersedia" }
        return XmlReport(root.tagName, shapes, effects, images, textLayers, duration, fps)
    }

    private fun formatXml(source: String): String {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            setFeature("http://xml.org/sax/features/external-general-entities", false)
            setFeature("http://xml.org/sax/features/external-parameter-entities", false)
            setExpandEntityReferences(false)
        }
        val builder = factory.newDocumentBuilder()
        builder.setEntityResolver { _, _ -> InputSource(StringReader("")) }
        val document = builder.parse(InputSource(StringReader(source)))
        val transformerFactory = TransformerFactory.newInstance().apply {
            try { setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "") } catch (_: Exception) { }
            try { setAttribute("http://javax.xml.XMLConstants/property/accessExternalStylesheet", "") } catch (_: Exception) { }
        }
        val transformer = transformerFactory.newTransformer().apply {
            setOutputProperty(OutputKeys.ENCODING, "UTF-8")
            setOutputProperty(OutputKeys.INDENT, "yes")
            setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no")
            try { setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2") } catch (_: Exception) { }
        }
        val output = StringWriter()
        transformer.transform(DOMSource(document), StreamResult(output))
        return output.toString()
    }

    private fun validateAndReport() {
        try {
            status.text = inspectXml(editor.text.toString()).toStatus()
        } catch (e: Exception) {
            status.text = "Status: XML belum valid • ${e.message ?: "Periksa isi XML"}"
        }
    }

    private fun showError(prefix: String, error: Exception) {
        val message = error.message?.take(180) ?: "Kesalahan tidak diketahui"
        status.text = "$prefix: $message"
        toast("$prefix: $message")
    }

    private fun addSection(parent: LinearLayout, label: String) {
        val view = TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(accent)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(2, dp(20), 2, dp(9))
            letterSpacing = 0.1f
        }
        parent.addView(view, matchWrap())
    }

    private fun addButton(parent: LinearLayout, label: String, detail: String, action: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            setBackgroundColor(panel)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        val heading = TextView(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val description = TextView(this).apply {
            text = detail
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, 0)
        }
        card.addView(heading, matchWrap())
        card.addView(description, matchWrap())
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
        parent.addView(card, params)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sujproject.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sujproject.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
\ndependencies {\n    implementation("androidx.activity:activity-ktx:1.9.3")\n}\n
# SUJ PROJECT — V9 Motion Translator + CapCut Effect Template

This source keeps the existing SUJ PROJECT UI and Save/export flow. The embedded CapCut base project is now the uploaded `1125-01.zip` project, normalized for the app's template reader.

Changes:
- Preserves all 15 CapCut effect tracks and their effect materials from the supplied project.
- Removes the sample video clips from the CapCut template before adding XML photo tracks, so the old sample footage does not remain underneath the translated project.
- Extends the retained template effect tracks to the XML scene duration.
- Keeps photo occurrences as separate CapCut video tracks at the XML `startTime` / `endTime`, preserving overlaps and ordering.
- Adds localized effect-name matching for the supplied template (for example `Riak`, `Cermin`, `Peregangan Piksel`, `Color Glitch 2`, `Solar Quake`, and `Ritme Layar`).
- Maps supported Alight Motion motion/effect properties to the closest available CapCut controls; cubic-Bezier easing and an approximate elastic curve are retained.
- Does not add an audio track. Add music manually in CapCut after opening the generated project.

Important:
- Alight Motion and CapCut do not share identical effect engines. The mapped effects are visual approximations, not guaranteed one-to-one conversions.
- The supplied CapCut project contains 15 effect tracks and no audio track. Its effects are retained in the generated project.
- The XML contains 32 layers, including non-photo layers; the current photo picker handles replaceable Android gallery photo references. This XML has 3 unique replaceable gallery-photo references.
- A Gradle build has not been run in this environment. Use the included GitHub Actions workflow to build the APK, then open the exported project in CapCut and test the motion/effects.

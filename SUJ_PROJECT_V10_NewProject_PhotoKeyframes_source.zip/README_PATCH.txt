SUJ PROJECT - PATCH SUMBER PROYEK BARU

Sumber dasar CapCut diganti dengan arsip proyek baru yang diberikan pengguna: 1127-01 (1).zip (folder internal 1127-01). XML aktif: PROYEK BARU 1 SUJ(1).xml.

Tahap perbaikan yang diterapkan:
- Pemrosesan keyframe transform foto memakai waktu timeline XML relatif terhadap startTime layer foto.
- Keyframe sebelum awal foto tidak lagi semuanya dijepit ke waktu 0. Nilai pada batas awal klip dihitung dari keyframe yang mengapitnya.
- Keyframe di dalam rentang klip dipertahankan pada offset lokal yang benar.
- Nilai pada batas akhir klip disampling agar animasi berakhir pada nilai yang sedang berlaku.
- Template proyek lama 1121 tidak lagi dipakai; asset capcut_base_project.zip sekarang berisi proyek baru 1127-01.

Batas pengujian:
- Source ZIP telah diperbarui dan diperiksa struktur arsip serta referensi file proyek.
- APK belum dikompilasi atau diuji pada CapCut. Interpolasi nilai tepat di batas klip saat ini memakai pendekatan linear; kurva easing pada keyframe asli di dalam klip tetap dibawa ke keyframe CapCut.
- Tahap ini fokus pada transform foto. Efek/audio belum divalidasi.

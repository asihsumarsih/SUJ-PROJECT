# SUJ PROJECT V9 – Full Motion Translator Fix

Perbaikan penerjemah XML Alight Motion ke paket proyek CapCut PC.

Perubahan utama:
- mempertahankan setiap kemunculan foto sebagai track tersendiri dan memberi render index pada track/segment;
- menerjemahkan posisi, skala X/Y, rotasi, opacity dan kurva cubic-bezier;
- menerjemahkan Fade In/Out menjadi keyframe alpha;
- menggandakan material efek untuk setiap instance agar nilai slider tidak berbagi nilai/default dari efek lain;
- memperluas pemetaan efek ke Blur, Jitter Blur, Ripple, Mirror, Pixel Stretch, Chrome Blur, serta pendekatan Exposure/Lift/Saturation.

Catatan: efek Alight Motion yang tidak mempunyai padanan di template CapCut (misalnya Luma Key dan Four Color Gradient) tetap tidak dapat disalin identik. Wajib diuji dengan membuka hasil proyek di CapCut PC.

SUJ PROJECT V9 - Perbaikan timing dan deteksi media XML

Perubahan pada sumber:
- Memperbaiki deteksi foto dari URI Android Media Documents yang dipakai Alight Motion (`content://com.android.providers.media.documents/document/image...`). Sebelumnya URI ini tidak dikenali sebagai slot foto, sehingga XML bisa terbaca seolah-olah tidak memiliki foto.
- Memperbaiki waktu keyframe Transform. Nilai `t` Transform pada XML ini adalah waktu komposisi dalam detik; sekarang dikonversi menjadi waktu lokal klip dengan mengurangi `startTime` layer.
- Keyframe di luar rentang layer tidak lagi ditumpuk pada awal/akhir klip. Nilai pada batas klip dihitung dari keyframe di sekitarnya agar gerakan tidak berubah drastis.
- Keyframe efek dengan waktu 0..1 diperluas mengikuti durasi klip, bukan dianggap sebagai detik mentah.
- Menghapus pemetaan Exposure, Lift, Saturation/Vibrance ke efek Player 3 karena bukan efek yang sama.
- Tile/Ubin tidak diterapkan sesuai arahan pengguna. Efek yang tidak memiliki padanan yang layak tidak dipaksakan menjadi efek CapCut lain.
- Mempertahankan konversi Fade In/Fade Out yang sudah ada.

Batasan dan pengujian:
- Beberapa efek yang dipetakan (misalnya Oscillate, Swing, Motion Blur, Wave Warp) masih merupakan pendekatan terhadap efek CapCut yang tersedia, bukan padanan satu-ke-satu.
- Proyek contoh XML `PROYEK BARU 1 SUJ.xml` dan contoh keyframe CapCut menjadi acuan analisis timing.
- Build Android/Gradle dan uji buka hasil proyek di CapCut belum dapat dijalankan di lingkungan ini. ZIP sumber telah diperbarui, tetapi belum boleh dianggap sebagai APK teruji.

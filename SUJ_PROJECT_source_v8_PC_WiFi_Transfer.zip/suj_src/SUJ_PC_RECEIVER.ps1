# SUJ PROJECT - penerima proyek CapCut dari HP melalui Wi-Fi
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$defaultDrafts = Join-Path $env:LOCALAPPDATA 'CapCut\User Data\Projects\com.lveditor.draft'
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = 'Pilih folder Drafts CapCut PC (folder tempat proyek CapCut disimpan).'
$dialog.ShowNewFolderButton = $true
if (Test-Path $defaultDrafts) { $dialog.SelectedPath = $defaultDrafts }
[void][System.Windows.Forms.MessageBox]::Show("Tutup CapCut PC terlebih dahulu.`nPilih folder Drafts CapCut PC pada jendela berikutnya. Setelah itu biarkan penerima tetap terbuka.", 'SUJ PROJECT')
if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit }
$drafts = $dialog.SelectedPath
$inbox = Join-Path $env:TEMP 'SUJ_PROJECT_Inbox'
New-Item -ItemType Directory -Force -Path $inbox | Out-Null
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Any, 8765)
try {
  $listener.Start()
  $ip = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -like '192.168.*' -and $_.InterfaceAlias -notmatch 'Loopback' } | Select-Object -First 1 -ExpandProperty IPAddress)
  [void][System.Windows.Forms.MessageBox]::Show("Penerima SUJ aktif.`nIP komputer: $ip`nPort: 8765`nMasukkan IP tersebut di SUJ pada HP. Jangan tutup jendela ini sampai transfer selesai.", 'SUJ PROJECT - Siap')
  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $stream = $client.GetStream()
      $headerBytes = New-Object System.Collections.Generic.List[byte]
      $tail = [System.Collections.Generic.Queue[byte]]::new()
      while ($true) {
        $b = $stream.ReadByte(); if ($b -lt 0) { throw 'Koneksi terputus sebelum header lengkap.' }
        $headerBytes.Add([byte]$b); $tail.Enqueue([byte]$b); if ($tail.Count -gt 4) { [void]$tail.Dequeue() }
        if ($tail.Count -eq 4 -and (($tail.ToArray() -join ',') -eq '13,10,13,10')) { break }
        if ($headerBytes.Count -gt 32768) { throw 'Header terlalu panjang.' }
      }
      $headers = [Text.Encoding]::ASCII.GetString($headerBytes.ToArray())
      if ($headers -notmatch '(?im)^Content-Length:\s*(\d+)') { throw 'Content-Length tidak ditemukan.' }
      $length = [int64]$Matches[1]
      $project = 'SUJ_PROJECT'
      if ($headers -match '(?im)^X-Project-Name:\s*([^\r\n]+)') { $project = $Matches[1].Trim() }
      $zipPath = Join-Path $inbox 'incoming.zip'
      $file = [IO.File]::Create($zipPath)
      try {
        $buffer = New-Object byte[] 65536; $remaining = $length
        while ($remaining -gt 0) {
          $read = $stream.Read($buffer, 0, [int][Math]::Min($buffer.Length, $remaining))
          if ($read -le 0) { throw 'Transfer ZIP terputus.' }
          $file.Write($buffer, 0, $read); $remaining -= $read
        }
      } finally { $file.Dispose() }
      $extract = Join-Path $inbox 'extract'
      if (Test-Path $extract) { Remove-Item $extract -Recurse -Force }
      Expand-Archive -LiteralPath $zipPath -DestinationPath $extract -Force
      $projectFolder = Get-ChildItem -LiteralPath $extract -Directory | Select-Object -First 1
      if (-not $projectFolder) { throw 'Folder proyek tidak ditemukan di dalam ZIP.' }
      $destination = Join-Path $drafts $projectFolder.Name
      if (Test-Path $destination) {
        $backup = "$destination`_backup_$(Get-Date -Format yyyyMMdd_HHmmss)"
        Move-Item -LiteralPath $destination -Destination $backup
      }
      Copy-Item -LiteralPath $projectFolder.FullName -Destination $destination -Recurse
      $body = [Text.Encoding]::UTF8.GetBytes("OK: Proyek $($projectFolder.Name) disalin ke Drafts CapCut.")
      $response = "HTTP/1.1 200 OK`r`nContent-Type: text/plain; charset=utf-8`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n"
      $head = [Text.Encoding]::ASCII.GetBytes($response); $stream.Write($head,0,$head.Length); $stream.Write($body,0,$body.Length); $stream.Flush()
      [void][System.Windows.Forms.MessageBox]::Show("Proyek berhasil disalin ke:`n$destination`nBuka CapCut PC untuk memeriksa proyek.", 'SUJ PROJECT - Berhasil')
    } catch {
      $msg = $_.Exception.Message
      $body = [Text.Encoding]::UTF8.GetBytes($msg)
      try { $response = "HTTP/1.1 500 Error`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n"; $head=[Text.Encoding]::ASCII.GetBytes($response); $stream.Write($head,0,$head.Length); $stream.Write($body,0,$body.Length); $stream.Flush() } catch {}
      [void][System.Windows.Forms.MessageBox]::Show("Gagal menerima proyek: $msg", 'SUJ PROJECT - Gagal')
    } finally { $client.Close() }
  }
} finally { $listener.Stop() }

# SUJ PROJECT

## Kirim paket proyek ke CapCut PC melalui Wi-Fi

1. HP dan komputer Windows harus berada pada Wi-Fi yang sama.
2. Tutup CapCut PC.
3. Di Windows, ekstrak source ini lalu klik dua kali `SUJ_PC_RECEIVER.bat`.
4. Pilih folder Drafts CapCut PC pada dialog yang muncul. Lokasi umum: `%LOCALAPPDATA%\CapCut\User Data\Projects\com.lveditor.draft`.
5. Jendela penerima menampilkan IP komputer. Masukkan IP itu ke kolom **KONEKSI CAPCUT PC** di SUJ.
6. Import XML, pilih foto yang diminta, lalu tekan **SIMPAN**. SUJ mengirim paket langsung ke PC; salinan ZIP tetap disimpan di `Download/SUJ PROJECT` sebagai cadangan.
7. Setelah pesan berhasil, buka CapCut PC dan periksa proyeknya.

Jika Windows Firewall bertanya, izinkan PowerShell pada jaringan privat. Jangan tutup jendela penerima sampai transfer selesai.

## Batasan yang masih perlu diuji

Transfer Wi-Fi dan penyalinan folder proyek belum membuktikan bahwa setiap versi CapCut PC akan mengenali paket tersebut. Konversi khusus efek/keyframe Alight Motion ke format internal CapCut juga belum lengkap; bagian itu memerlukan pemetaan format XML dan pengujian pada proyek CapCut nyata.

@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SUJ_PC_RECEIVER.ps1"
pause

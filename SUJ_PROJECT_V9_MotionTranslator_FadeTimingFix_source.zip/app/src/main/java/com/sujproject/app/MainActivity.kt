package com.sujproject.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.xml.sax.InputSource
import java.io.StringReader
import java.io.StringWriter
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import org.json.JSONArray
import org.json.JSONObject
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

class MainActivity : ComponentActivity() {
    private val black = Color.rgb(12, 12, 12)
    private val card = Color.rgb(35, 35, 35)
    private val purple = Color.rgb(174, 0, 220)
    private val green = Color.rgb(50, 220, 95)
    private val white = Color.WHITE

    private var xmlText = ""
    private var xmlName = ""
    private var draftName = "1021-03 (IKP2)"
    private var mediaRefs = mutableListOf<String>()
    private var selectedPhotos = mutableMapOf<Int, Uri>()
    private lateinit var page: LinearLayout
    private lateinit var xmlStatus: TextView
    private lateinit var mediaArea: LinearLayout
    private lateinit var bottomStatus: TextView

    private val importXml = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            try {
                xmlText = contentResolver.openInputStream(uri)?.use { input ->
                    val bytes = input.readBytes()
                    decodeXml(bytes)
                } ?: error("File tidak dapat dibaca")
                val parsed = parseMedia(xmlText)
                mediaRefs = parsed.toMutableList()
                selectedPhotos.clear()
                xmlName = getDisplayName(uri) ?: "Proyek.xml"
                renderConverter()
                xmlStatus.text = "● primary:$xmlName"
                xmlStatus.setTextColor(green)
                bottomStatus.text = "Terdeteksi ${mediaRefs.size} foto sumber. Tiap kemunculan foto akan dibuat pada timeline."
                bottomStatus.setTextColor(green)
            } catch (e: Exception) {
                xmlText = ""
                mediaRefs.clear()
                renderConverter()
                xmlStatus.text = "● XML gagal dimuat: ${e.message ?: "format tidak dikenali"}"
                xmlStatus.setTextColor(Color.RED)
            }
        }
    }

    private var pickingIndex = -1
    private val pickPhoto = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null && pickingIndex >= 0) {
            try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            selectedPhotos[pickingIndex] = uri
            renderMediaRows()
            bottomStatus.text = "Foto ${pickingIndex + 1} berhasil dipilih."
            bottomStatus.setTextColor(green)
        }
    }

    private val saveProject = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) saveConverted(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        showHome()
    }

    private fun showHome() {
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(24), dp(30), dp(24), dp(24))
        }
        val title = TextView(this).apply {
            text = "SUJ PROJECT"
            textSize = 28f
            setTextColor(Color.BLACK)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(10), 0, dp(38))
        }
        root.addView(title)
        val menu = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val icon = TextView(this).apply {
            text = "↕"
            textSize = 48f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        val label = TextView(this).apply {
            text = "XmlConvert"
            textSize = 14f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        menu.addView(icon, LinearLayout.LayoutParams(dp(110), dp(68)))
        menu.addView(label, LinearLayout.LayoutParams(dp(110), dp(30)))
        menu.setOnClickListener { renderConverter() }
        root.addView(menu, LinearLayout.LayoutParams(dp(130), dp(110)))
        setContentView(root)
    }

    private fun renderConverter() {
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(black) }
        val scroll = ScrollView(this)
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(black)
            setPadding(dp(18), dp(24), dp(18), dp(12))
        }
        val projectLabel = TextView(this).apply {
            text = "PILIH PROYEK (DRAF)"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(20))
        }
        page.addView(projectLabel)
        val project = TextView(this).apply {
            text = draftName + "   ▾"
            textSize = 16f
            setTextColor(white)
            setPadding(dp(8), dp(8), dp(8), dp(12))
            setOnClickListener {
                val edit = EditText(this@MainActivity).apply { setText(draftName); setSingleLine(true) }
                AlertDialog.Builder(this@MainActivity).setTitle("Pilih Proyek (Draf)")
                    .setMessage("Masukkan nama draf CapCut yang ingin digunakan")
                    .setView(edit).setNegativeButton("BATAL", null)
                    .setPositiveButton("OK") { _, _ -> draftName = edit.text.toString().ifBlank { draftName }; renderConverter() }.show()
            }
        }
        page.addView(project)
        xmlStatus = TextView(this).apply {
            text = if (xmlText.isBlank()) "● XML Belum Dimuat" else "● primary:$xmlName"
            textSize = 14f
            setTextColor(if (xmlText.isBlank()) Color.rgb(240, 75, 115) else green)
            setPadding(0, dp(8), 0, dp(16))
        }
        page.addView(xmlStatus)
        val import = TextView(this).apply {
            text = "IMPORT XML"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(white)
            setBackgroundColor(card)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { importXml.launch(arrayOf("application/xml", "text/xml", "application/*", "*/*")) }
        }
        page.addView(import, LinearLayout.LayoutParams(-1, dp(48)))
        val mediaTitle = TextView(this).apply {
            text = "Media dalam Draf"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(white)
            setPadding(0, dp(32), 0, dp(24))
        }
        page.addView(mediaTitle)
        mediaArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(mediaArea)
        bottomStatus = TextView(this).apply {
            text = if (mediaRefs.isEmpty()) "Menunggu perintah..." else "Terdeteksi ${mediaRefs.size} foto sumber. Tiap kemunculan foto akan dibuat pada timeline."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
            setPadding(dp(4), dp(18), dp(4), dp(14))
        }
        page.addView(bottomStatus)
        scroll.addView(page)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(8), dp(14), dp(12))
            setBackgroundColor(black)
        }
        val cancel = actionButton("BATAL", Color.rgb(65,65,65)) { showHome() }
        val save = actionButton("SIMPAN", purple) {
            if (xmlText.isBlank()) Toast.makeText(this, "Import XML terlebih dahulu", Toast.LENGTH_SHORT).show()
            else if (mediaRefs.isNotEmpty() && selectedPhotos.size < mediaRefs.size) {
                bottomStatus.text = "Pilih semua ${mediaRefs.size} foto terlebih dahulu."
                bottomStatus.setTextColor(Color.RED)
            } else saveProject.launch((draftName.ifBlank { "SUJ_PROJECT" }).replace(Regex("[^A-Za-z0-9._ -]"), "_") + "_CapCut_Project.zip")
        }
        buttons.addView(cancel, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(8) })
        buttons.addView(save, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(8) })
        outer.addView(buttons)
        setContentView(outer)
        renderMediaRows()
    }

    private fun renderMediaRows() {
        if (!::mediaArea.isInitialized) return
        mediaArea.removeAllViews()
        if (mediaRefs.isEmpty()) return
        val ranges = findRanges(xmlText, mediaRefs.size)
        val hint = TextView(this).apply {
            text = "Diperlukan ${mediaRefs.size} foto sumber (dipakai ulang sesuai kemunculan di XML)"
            textSize = 13f
            setTextColor(purple)
            setPadding(0, 0, 0, dp(12))
        }
        mediaArea.addView(hint)
        mediaRefs.forEachIndexed { index, ref ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
                setBackgroundColor(Color.rgb(27,27,27))
            }
            val thumb = TextView(this).apply {
                text = if (selectedPhotos.containsKey(index)) "✓" else "▧"
                textSize = 25f
                gravity = Gravity.CENTER
                setTextColor(if (selectedPhotos.containsKey(index)) green else Color.GRAY)
                setBackgroundColor(card)
            }
            row.addView(thumb, LinearLayout.LayoutParams(dp(66), dp(66)))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(6), 0) }
            val title = TextView(this).apply { text = "Foto ${index + 1}  (${ranges.getOrNull(index) ?: "Media XML"})"; textSize = 14f; setTextColor(white) }
            val sub = TextView(this).apply {
                text = "Asli: ${ref.take(34)}${if (ref.length > 34) "..." else ""}"
                textSize = 10f; setTextColor(Color.LTGRAY); setPadding(0, dp(4), 0, 0)
            }
            info.addView(title); info.addView(sub)
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val choose = TextView(this).apply {
                text = if (selectedPhotos.containsKey(index)) "GANTI" else "PILIH"
                textSize = 12f; gravity = Gravity.CENTER; setTextColor(white); setBackgroundColor(Color.rgb(116, 0, 150)); setPadding(dp(12), dp(12), dp(12), dp(12))
                setOnClickListener { pickingIndex = index; pickPhoto.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
            }
            row.addView(choose, LinearLayout.LayoutParams(dp(68), dp(42)))
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
            mediaArea.addView(row, lp)
        }
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 16f; gravity = Gravity.CENTER; setTextColor(white); setBackgroundColor(color)
        setOnClickListener { click() }
    }

    // Use the document provider's display name, not its opaque URI/document ID.
    private fun getDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (column >= 0) return cursor.getString(column)
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.contains('.') }
    }

    // Decode XML using its BOM or XML declaration; remove a UTF-8 BOM before parsing.
    private fun decodeXml(bytes: ByteArray): String {
        if (bytes.isEmpty()) error("File XML kosong")
        val decoded = when {
            bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte() ->
                String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
            bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte() ->
                String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
            bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte() ->
                String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
            else -> String(bytes, Charsets.UTF_8)
        }
        return decoded.trimStart('\uFEFF', '\u0000', ' ', '\n', '\r', '\t')
    }

    private fun allElements(doc: Document): List<Element> {
        val nodes = doc.getElementsByTagName("*")
        val result = ArrayList<Element>(nodes.length)
        for (i in 0 until nodes.length) {
            (nodes.item(i) as? Element)?.let { result.add(it) }
        }
        return result
    }

    private fun tagName(el: Element): String =
        (el.localName ?: el.tagName.substringAfter(':')).lowercase()

    private fun attr(el: Element, name: String): String {
        if (el.hasAttribute(name)) return el.getAttribute(name)
        val attrs = el.attributes
        for (i in 0 until attrs.length) {
            val node = attrs.item(i)
            if ((node.localName ?: node.nodeName.substringAfter(':')).equals(name, true)) {
                return node.nodeValue ?: ""
            }
        }
        return ""
    }

    // Only Android gallery image references are replaceable photo slots.
    // Alight Motion internal assets (for example am:...jpg) must stay untouched.
    private fun isReplaceablePhotoReference(value: String): Boolean {
        val v = value.trim().lowercase()
        return v.startsWith("content://media/external/images/") ||
            v.startsWith("content://media/external/image/")
    }

    private fun parseMedia(source: String): List<String> {
        require(source.isNotBlank()) { "File XML kosong" }
        val doc = parseDocument(source)
        val found = linkedSetOf<String>()
        for (el in allElements(doc)) {
            if (tagName(el) != "shape" || !attr(el, "fillType").equals("media", true)) continue
            val value = attr(el, "fillImage").ifBlank { attr(el, "media") }
            if (isReplaceablePhotoReference(value)) found.add(value)
        }
        return found.toList()
    }

    private fun parseDocument(source: String): Document {
        val clean = source.trimStart('\uFEFF', '\u0000', ' ', '\n', '\r', '\t')
        require(clean.isNotBlank()) { "File XML kosong" }
        val factory = DocumentBuilderFactory.newInstance()
        factory.isNamespaceAware = true
        factory.isExpandEntityReferences = false
        // Android versions differ in which parser security features they support.
        try { factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (_: Exception) { }
        try { factory.setFeature("http://xml.org/sax/features/external-general-entities", false) } catch (_: Exception) { }
        try { factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false) } catch (_: Exception) { }
        val builder = factory.newDocumentBuilder()
        builder.setEntityResolver { _, _ -> InputSource(StringReader("")) }
        return builder.parse(InputSource(StringReader(clean)))
    }

    private fun findRanges(source: String, count: Int): List<String> {
        val doc = try { parseDocument(source) } catch (_: Exception) { return emptyList() }
        data class Span(var start: Long, var end: Long)
        val spans = linkedMapOf<String, Span>()
        for (el in allElements(doc)) {
            if (tagName(el) != "shape" || !attr(el, "fillType").equals("media", true)) continue
            val value = attr(el, "fillImage").ifBlank { attr(el, "media") }
            if (!isReplaceablePhotoReference(value)) continue
            val start = attr(el, "startTime").toLongOrNull() ?: continue
            val end = attr(el, "endTime").toLongOrNull() ?: continue
            val span = spans[value]
            if (span == null) spans[value] = Span(start, end)
            else {
                if (start < span.start) span.start = start
                if (end > span.end) span.end = end
            }
        }
        return spans.values.take(count).map {
            "%.2fs - %.2fs".format(it.start / 1000.0, it.end / 1000.0)
        }
    }

    private data class MediaSlot(val ref: String, val startMs: Long, val endMs: Long)

    private fun collectMediaSlots(): List<MediaSlot> {
        val doc = parseDocument(xmlText)
        val slots = linkedMapOf<String, MediaSlot>()
        for (el in allElements(doc)) {
            if (tagName(el) != "shape" || !attr(el, "fillType").equals("media", true)) continue
            val ref = attr(el, "fillImage").ifBlank { attr(el, "media") }
            if (!isReplaceablePhotoReference(ref)) continue
            val start = attr(el, "startTime").toLongOrNull()?.coerceAtLeast(0) ?: 0L
            val end = attr(el, "endTime").toLongOrNull()?.coerceAtLeast(start + 1000L) ?: (start + 5000L)
            val old = slots[ref]
            slots[ref] = if (old == null) MediaSlot(ref, start, end)
                else MediaSlot(ref, minOf(old.startMs, start), maxOf(old.endMs, end))
        }
        return slots.values.toList()
    }

    private data class MediaOccurrence(val ref: String, val startMs: Long, val endMs: Long, val element: Element)

    // Keep every appearance of a photo as its own timeline segment. The picker still asks
    // once per unique source image, then reuses that selected image for every occurrence.
    private fun collectMediaOccurrences(): List<MediaOccurrence> {
        val doc = parseDocument(xmlText)
        return allElements(doc).mapNotNull { el ->
            if (tagName(el) != "shape" || !attr(el, "fillType").equals("media", true)) return@mapNotNull null
            val ref = attr(el, "fillImage").ifBlank { attr(el, "media") }
            if (!isReplaceablePhotoReference(ref)) return@mapNotNull null
            val start = attr(el, "startTime").toLongOrNull()?.coerceAtLeast(0L) ?: 0L
            val end = attr(el, "endTime").toLongOrNull()?.coerceAtLeast(start + 1L) ?: (start + 1000L)
            MediaOccurrence(ref, start, maxOf(start + 1L, end), el)
        }.sortedWith(compareBy<MediaOccurrence> { it.startMs }.thenBy { it.endMs })
    }

    private fun childElement(parent: Element, name: String): Element? {
        val nodes = parent.childNodes
        for (i in 0 until nodes.length) {
            val node = nodes.item(i)
            if (node is Element && tagName(node) == name.lowercase()) return node
        }
        return null
    }

    private fun csvNumbers(value: String): List<Double> = value.split(',').mapNotNull { it.trim().toDoubleOrNull() }

    private data class XmlKeyframe(val time: Double, val values: List<Double>, val easing: String = "")

    private fun easingControls(easing: String): Pair<JSONObject, JSONObject> {
        val nums = Regex("[-+]?(?:\\d*\\.)?\\d+").findAll(easing).mapNotNull { it.value.toDoubleOrNull() }.toList()
        if (easing.startsWith("cubicBezier", true) && nums.size >= 4) {
            return JSONObject().put("x", nums[0]).put("y", nums[1]) to
                JSONObject().put("x", nums[2]).put("y", nums[3])
        }
        // CapCut does not expose Alight Motion's elastic curve parameters in the
        // same format. Use a gentle Bezier approximation instead of silently
        // turning every elastic keyframe into a linear segment.
        if (easing.contains("elastic", true)) {
            val reverse = easing.contains("reverse", true)
            return if (reverse) {
                JSONObject().put("x", 0.18).put("y", 0.0) to JSONObject().put("x", 0.82).put("y", 1.18)
            } else {
                JSONObject().put("x", 0.18).put("y", -0.18) to JSONObject().put("x", 0.82).put("y", 1.0)
            }
        }
        return JSONObject().put("x", 0.0).put("y", 0.0) to JSONObject().put("x", 0.0).put("y", 0.0)
    }

    private fun makeCommonKeyframeGroup(property: String, points: List<XmlKeyframe>, durationUs: Long): JSONObject? {
        if (points.isEmpty()) return null
        val list = JSONArray()
        // Alight Motion XML stores keyframe `t` in seconds relative to the layer,
        // NOT as a 0..1 fraction. In real presets times can be negative (pre-roll)
        // or greater than one second. Normalizing min/max here stretches the motion
        // and changes the beat timing, which is why the imported JJ looked different.
        // Convert seconds directly to CapCut microseconds and clamp only to this clip.
        points.sortedBy { it.time }.forEach { point ->
            val offset = (point.time * 1_000_000.0).toLong().coerceIn(0L, durationUs)
            val (left, right) = easingControls(point.easing)
            val kf = JSONObject()
                .put("id", UUID.randomUUID().toString().uppercase())
                .put("curveType", if (point.easing.startsWith("cubicBezier", true) || point.easing.contains("elastic", true)) "Bezier" else "Line")
                .put("time_offset", offset.toLong().coerceIn(0L, durationUs))
                .put("left_control", left)
                .put("right_control", right)
                .put("values", JSONArray(point.values))
                .put("string_value", "")
                .put("graphID", "")
            list.put(kf)
        }
        return JSONObject().put("id", UUID.randomUUID().toString().uppercase())
            .put("material_id", "").put("property_type", property).put("keyframe_list", list)
    }

    private fun convertTransformKeyframes(shape: Element, durationUs: Long, sceneWidth: Double, sceneHeight: Double): JSONArray {
        val result = JSONArray()
        val transform = childElement(shape, "transform") ?: return result
        val mappings = listOf(
            Triple("location", "KFTypePositionX", 0), Triple("location", "KFTypePositionY", 1),
            Triple("scale", "KFTypeScaleX", 0), Triple("scale", "KFTypeScaleY", 1),
            Triple("rotation", "KFTypeRotation", 0), Triple("opacity", "KFTypeAlpha", 0)
        )
        for ((tag, property, component) in mappings) {
            val element = childElement(transform, tag) ?: continue
            val keyframes = ArrayList<XmlKeyframe>()
            val nodes = element.getElementsByTagName("kf")
            if (nodes.length > 0) {
                for (i in 0 until nodes.length) {
                    val kf = nodes.item(i) as? Element ?: continue
                    val time = attr(kf, "t").toDoubleOrNull() ?: continue
                    val values = csvNumbers(attr(kf, "v"))
                    if (values.isEmpty()) continue
                    val raw = when (tag) {
                        "location", "scale" -> values.getOrNull(component) ?: values.first()
                        else -> values.first()
                    }
                    val normalized = when (tag) {
                        "location" -> if (component == 0) (raw - sceneWidth / 2.0) / (sceneWidth / 2.0) else (raw - sceneHeight / 2.0) / (sceneHeight / 2.0)
                        "opacity" -> if (raw > 1.0) raw / 100.0 else raw
                        else -> raw
                    }
                    keyframes.add(XmlKeyframe(time, listOf(normalized), attr(kf, "e")))
                }
            } else {
                val values = csvNumbers(attr(element, "value"))
                if (values.isNotEmpty()) {
                    val raw = when (tag) {
                        "location", "scale" -> values.getOrNull(component) ?: values.first()
                        else -> values.first()
                    }
                    val normalized = when (tag) {
                        "location" -> if (component == 0) (raw - sceneWidth / 2.0) / (sceneWidth / 2.0) else (raw - sceneHeight / 2.0) / (sceneHeight / 2.0)
                        "opacity" -> if (raw > 1.0) raw / 100.0 else raw
                        else -> raw
                    }
                    keyframes.add(XmlKeyframe(0.0, listOf(normalized)))
                }
            }
            makeCommonKeyframeGroup(property, keyframes, durationUs)?.let { result.put(it) }
        }
        // Alight Motion Fade is a layer effect, not a transform. Translate its timing
        // into alpha keyframes so the photo actually fades in/out in CapCut.
        val fade = (0 until shape.childNodes.length).mapNotNull { shape.childNodes.item(it) as? Element }
            .firstOrNull { tagName(it) == "effect" && attr(it, "id").lowercase().endsWith(".fade") }
        if (fade != null) {
            fun fadeValue(name: String): Double = fade.getElementsByTagName("property").let { list ->
                (0 until list.length).mapNotNull { list.item(it) as? Element }
                    .firstOrNull { attr(it, "name") == name }?.let { attr(it, "value").toDoubleOrNull() } ?: 0.0
            }
            val fadeInUs = (fadeValue("inTime") * 1_000_000.0).toLong().coerceIn(0L, durationUs)
            val fadeOutUs = (fadeValue("outTime") * 1_000_000.0).toLong().coerceIn(0L, durationUs)
            val alphaPoints = arrayListOf(XmlKeyframe(0.0, listOf(if (fadeInUs > 0) 0.0 else 1.0)))
            // XmlKeyframe.time is always expressed in seconds. Do not pass a
            // normalized 0..1 fraction here: makeCommonKeyframeGroup converts
            // seconds to microseconds, so fractions would compress the fade.
            if (fadeInUs > 0) alphaPoints.add(XmlKeyframe(fadeInUs / 1_000_000.0, listOf(1.0), "cubicBezier 0.42 0.0 0.58 1.0"))
            if (fadeOutUs > 0) {
                alphaPoints.add(XmlKeyframe((durationUs - fadeOutUs) / 1_000_000.0, listOf(1.0)))
                alphaPoints.add(XmlKeyframe(durationUs / 1_000_000.0, listOf(0.0), "cubicBezier 0.42 0.0 0.58 1.0"))
            }
            makeCommonKeyframeGroup("KFTypeAlpha", alphaPoints, durationUs)?.let { result.put(it) }
        }
        return result
    }

    // Apply non-animated transform values too. Alight Motion often stores the photo's
    // actual placement in value="..." while only scale/rotation has keyframes.
    private fun applyStaticTransform(shape: Element, segment: JSONObject, sceneWidth: Double, sceneHeight: Double) {
        val transform = childElement(shape, "transform") ?: return
        val clip = segment.optJSONObject("clip") ?: JSONObject()
        val location = childElement(transform, "location")?.let { csvNumbers(attr(it, "value")) }.orEmpty()
        if (location.size >= 2) {
            val x = (location[0] - sceneWidth / 2.0) / (sceneWidth / 2.0)
            val y = (location[1] - sceneHeight / 2.0) / (sceneHeight / 2.0)
            val position = clip.optJSONObject("transform") ?: JSONObject()
            position.put("x", x).put("y", y)
            clip.put("transform", position)
        }
        val scale = childElement(transform, "scale")?.let { csvNumbers(attr(it, "value")) }.orEmpty()
        if (scale.isNotEmpty()) {
            val scaleObject = clip.optJSONObject("scale") ?: JSONObject()
            scaleObject.put("x", scale[0]).put("y", scale.getOrNull(1) ?: scale[0])
            clip.put("scale", scaleObject)
        }
        childElement(transform, "rotation")?.let { csvNumbers(attr(it, "value")).firstOrNull() }?.let { clip.put("rotation", it) }
        childElement(transform, "opacity")?.let { csvNumbers(attr(it, "value")).firstOrNull() }?.let {
            clip.put("alpha", if (it > 1.0) it / 100.0 else it)
        }
        segment.put("clip", clip)
    }

    private fun effectTemplateName(amId: String): String? {
        val id = amId.lowercase()
        return when {
            id.contains("gaussianblur") -> "Blur"
            id.contains("motionblur") -> "Jitter Blur"
            id.contains("circularripple") || id.contains("wavewarp") -> "Riak"
            id.endsWith(".tile") || id.endsWith(".mirror") -> "Cermin"
            id.contains("randomdisplace") || id.contains("displacemap") || id.contains("stretch2") -> "Peregangan Piksel"
            id.contains("rgbsep") -> "Color Glitch 2"
            id.contains("flip3") -> "Ruang berputar"
            id.contains("oscillate") -> "Solar Quake"
            id.contains("swing2") -> "Ritme Layar"
            id.contains("exposure") || id.endsWith(".lift") || id.contains("satvib") -> "Player 3"
            else -> null
        }
    }

    private fun effectPropertyMap(amId: String, property: String): String? {
        val id = amId.lowercase(); val p = property.lowercase()
        return when {
            id.contains("gaussianblur") && p == "strength" -> "effects_adjust_blur"
            id.contains("motionblur") && p == "tune" -> "effects_adjust_blur"
            id.contains("exposure") && p == "exposure" -> "effects_adjust_luminance"
            id.endsWith(".lift") && p == "fill" -> "effects_adjust_luminance"
            id.contains("satvib") && p == "saturation" -> "effects_adjust_horizontal_chromatic"
            id.contains("satvib") && p == "vib" -> "effects_adjust_texture"
            id.contains("circularripple") && p == "strength" -> "effects_adjust_intensity"
            id.contains("circularripple") && p == "frequency" -> "effects_adjust_speed"
            id.contains("circularripple") && p == "radius" -> "effects_adjust_size"
            id.contains("wavewarp") && (p == "m1" || p == "m2") -> "effects_adjust_size"
            id.contains("wavewarp") && p == "phase" -> "effects_adjust_speed"
            id.contains("randomdisplace") && p == "mag" -> "effects_adjust_distortion"
            id.contains("randomdisplace") && p == "evolution" -> "effects_adjust_speed"
            id.contains("stretch2") && p == "scale" -> "effects_adjust_distortion"
            id.contains("rgbsep") && p == "strength" -> "effects_adjust_horizontal_chromatic"
            id.contains("rgbsep") && p == "angle" -> "effects_adjust_speed"
            id.endsWith(".tile") && p == "scale" -> "effects_adjust_size"
            id.contains("flip3") && p == "angle" -> "effects_adjust_rotate"
            id.contains("oscillate") && p == "freq" -> "effects_adjust_speed"
            id.contains("oscillate") && p == "mag" -> "effects_adjust_intensity"
            id.contains("oscillate") && p == "angle" -> "effects_adjust_distortion"
            id.contains("swing2") && p == "freq" -> "effects_adjust_speed"
            id.contains("displacemap") && p == "offs" -> "effects_adjust_distortion"
            else -> null
        }
    }

    private fun normalizeEffectValue(amId: String, property: String, value: Double): Double {
        val id = amId.lowercase(); val p = property.lowercase()
        val mapped = when {
            id.contains("exposure") && p == "exposure" -> 0.4 + value * 0.25
            id.endsWith(".lift") && p == "fill" -> 0.4 + value * 0.5
            id.contains("satvib") && p == "saturation" -> (value + 1.0) / 2.0
            id.contains("satvib") && p == "vib" -> value / 2.0
            id.contains("randomdisplace") && p == "mag" -> value / 250.0
            id.contains("randomdisplace") && p == "evolution" -> value / 5.0
            id.contains("stretch2") && p == "scale" -> (value - 1.0) / 0.35
            id.contains("rgbsep") && p == "strength" -> kotlin.math.abs(value)
            id.contains("rgbsep") && p == "angle" -> value / 360.0
            id.contains("flip3") && p == "angle" -> value / 360.0
            id.contains("oscillate") && p == "mag" -> value / 50.0
            id.contains("oscillate") && p == "angle" -> value / 180.0
            id.contains("displacemap") && p == "offs" -> value / 250.0
            id.contains("circularripple") && p == "strength" -> value * 20.0
            id.contains("circularripple") && p == "frequency" -> value / 10.0
            id.contains("circularripple") && p == "radius" -> value
            id.contains("wavewarp") && (p == "m1" || p == "m2") -> value / 40.0
            id.contains("wavewarp") && p == "phase" -> value / 2.0
            else -> value
        }
        return mapped.coerceIn(-1.0, 1.0)
    }

    private fun convertEffectKeyframes(effect: Element, durationUs: Long): JSONArray {
        val result = JSONArray(); val effectId = attr(effect, "id")
        val nodes = effect.childNodes
        for (i in 0 until nodes.length) {
            val prop = nodes.item(i) as? Element ?: continue
            if (tagName(prop) != "property") continue
            val propertyType = effectPropertyMap(effectId, attr(prop, "name")) ?: continue
            val points = ArrayList<XmlKeyframe>(); val kfs = prop.getElementsByTagName("kf")
            if (kfs.length > 0) {
                for (j in 0 until kfs.length) {
                    val kf = kfs.item(j) as? Element ?: continue
                    val t = attr(kf, "t").toDoubleOrNull() ?: continue
                    val value = attr(kf, "v").toDoubleOrNull() ?: continue
                    points.add(XmlKeyframe(t, listOf(normalizeEffectValue(effectId, attr(prop, "name"), value)), attr(kf, "e")))
                }
            } else attr(prop, "value").toDoubleOrNull()?.let {
                points.add(XmlKeyframe(0.0, listOf(normalizeEffectValue(effectId, attr(prop, "name"), it))))
            }
            makeCommonKeyframeGroup(propertyType, points, durationUs)?.let { result.put(it) }
        }
        return result
    }

    // Clone the effect material for every translated XML effect. CapCut stores the
    // default/static slider values in materials.video_effects.adjust_params; changing
    // only segment keyframes leaves many imported effects at the template defaults.
    private fun cloneEffectMaterial(source: JSONObject, effect: Element, materials: JSONObject): String {
        val clone = jsonClone(source)
        val newId = UUID.randomUUID().toString().uppercase()
        clone.put("id", newId)
        val params = clone.optJSONArray("adjust_params") ?: JSONArray()
        val nodes = effect.childNodes
        for (i in 0 until nodes.length) {
            val prop = nodes.item(i) as? Element ?: continue
            if (tagName(prop) != "property") continue
            val paramName = effectPropertyMap(attr(effect, "id"), attr(prop, "name")) ?: continue
            val raw = attr(prop, "value").toDoubleOrNull() ?: (prop.getElementsByTagName("kf").item(0) as? Element)
                ?.let { attr(it, "v").toDoubleOrNull() } ?: continue
            val value = normalizeEffectValue(attr(effect, "id"), attr(prop, "name"), raw)
            for (j in 0 until params.length()) {
                val item = params.optJSONObject(j) ?: continue
                if (item.optString("name") == paramName) item.put("value", value)
            }
        }
        val list = materials.optJSONArray("video_effects") ?: JSONArray().also { materials.put("video_effects", it) }
        list.put(clone)
        return newId
    }

    private fun readAssetText(name: String): String = assets.open(name).bufferedReader(Charsets.UTF_8).use { it.readText() }

    private fun readBaseProjectEntry(path: String): ByteArray {
        ZipInputStream(assets.open("capcut_base_project.zip")).use { input ->
            while (true) {
                val entry = input.nextEntry ?: break
                if (!entry.isDirectory && entry.name == path) return input.readBytes()
            }
        }
        error("File template CapCut tidak ditemukan: $path")
    }

    private fun readBaseProjectJson(path: String): JSONObject =
        JSONObject(readBaseProjectEntry(path).toString(Charsets.UTF_8))

    private fun jsonClone(source: JSONObject): JSONObject = JSONObject(source.toString())

    private fun saveConverted(uri: Uri) {
        try {
            val occurrences = collectMediaOccurrences()
            require(occurrences.isNotEmpty() || mediaRefs.isEmpty()) { "Slot foto XML tidak terbaca" }
            require(mediaRefs.all { selectedPhotos.containsKey(mediaRefs.indexOf(it)) }) { "Pilih semua foto XML terlebih dahulu" }

            // Start from the supplied CapCut PC project and preserve every original track.
            val draft = readBaseProjectJson("1121/draft_content.json")
            val templateTracks = draft.optJSONArray("tracks") ?: JSONArray()
            // Use one original video segment only as a schema/template for the new photo clips.
            // Remove the template's sample footage, but keep every user-supplied effect track.
            val videoTrackSource = (0 until templateTracks.length()).mapNotNull { templateTracks.optJSONObject(it) }
                .firstOrNull { it.optString("type") == "video" } ?: error("Track video template tidak ditemukan")
            val baseSegment = videoTrackSource.getJSONArray("segments").getJSONObject(0)
            val baseMaterial = draft.getJSONObject("materials").getJSONArray("videos").getJSONObject(0)
            val baseTracks = JSONArray()
            for (i in 0 until templateTracks.length()) {
                val track = templateTracks.optJSONObject(i) ?: continue
                if (track.optString("type") != "video") baseTracks.put(track)
            }
            draft.put("tracks", baseTracks)
            val projectInfo = readBaseProjectJson("1121/Timelines/project.json")
            val originalTimelineId = projectInfo.getJSONArray("timelines").getJSONObject(0).getString("id")
            val materials = draft.getJSONObject("materials")
            val imageMaterials = materials.optJSONArray("images") ?: JSONArray().also { materials.put("images", it) }
            val materialByRef = linkedMapOf<String, String>()
            val mediaBytes = linkedMapOf<String, ByteArray>()

            mediaRefs.forEachIndexed { index, ref ->
                val photoUri = selectedPhotos[index] ?: error("Foto ${index + 1} belum dipilih")
                val bytes = contentResolver.openInputStream(photoUri)?.use { it.readBytes() }
                    ?: error("Foto ${index + 1} tidak dapat dibaca")
                require(bytes.isNotEmpty()) { "Foto ${index + 1} kosong" }
                val ext = when (contentResolver.getType(photoUri)?.lowercase()) {
                    "image/png" -> "png"
                    "image/webp" -> "webp"
                    "image/gif" -> "gif"
                    else -> "jpg"
                }
                val fileName = "photo_${index + 1}.$ext"
                mediaBytes[fileName] = bytes
                val materialId = UUID.randomUUID().toString().uppercase()
                val material = jsonClone(baseMaterial)
                material.put("id", materialId)
                material.put("unique_id", UUID.randomUUID().toString().replace("-", ""))
                material.put("type", "photo")
                material.put("duration", maxOf(1000000L, (draft.optLong("duration", 20000000L))))
                material.put("path", "media/$fileName")
                material.put("media_path", "media/$fileName")
                material.put("material_name", fileName)
                material.put("name", fileName)
                material.put("has_audio", false)
                material.put("local_material_id", UUID.randomUUID().toString())
                imageMaterials.put(material)
                materialByRef[ref] = materialId
            }

            val scene = parseDocument(xmlText).documentElement
            val sceneWidth = attr(scene, "width").toDoubleOrNull() ?: 1080.0
            val sceneHeight = attr(scene, "height").toDoubleOrNull() ?: 1920.0
            var totalUs = maxOf(draft.optLong("duration", 0L),
                (attr(scene, "totalTime").toLongOrNull() ?: 0L) * 1000L)
            // Keep the template effects active for the full XML timeline, not only
            // the shorter duration of the example CapCut project.
            for (ti in 0 until baseTracks.length()) {
                val track = baseTracks.optJSONObject(ti) ?: continue
                if (track.optString("type") != "effect") continue
                val segments = track.optJSONArray("segments") ?: continue
                for (si in 0 until segments.length()) {
                    val effectSegment = segments.optJSONObject(si) ?: continue
                    val sourceRange = effectSegment.optJSONObject("source_timerange") ?: JSONObject()
                    sourceRange.put("start", 0).put("duration", totalUs)
                    effectSegment.put("source_timerange", sourceRange)
                    val targetRange = effectSegment.optJSONObject("target_timerange") ?: JSONObject()
                    targetRange.put("start", 0).put("duration", totalUs)
                    effectSegment.put("target_timerange", targetRange)
                }
            }
            var renderIndex = baseTracks.length()

            // Each AM photo layer becomes a CapCut video track. This preserves overlap and z-order.
            occurrences.forEachIndexed { index, occurrence ->
                val materialId = materialByRef[occurrence.ref] ?: error("Foto sumber tidak dipilih")
                val durationUs = ((occurrence.endMs - occurrence.startMs).coerceAtLeast(1L)) * 1000L
                val targetStartUs = occurrence.startMs * 1000L
                val segment = jsonClone(baseSegment)
                segment.put("id", UUID.randomUUID().toString().uppercase())
                segment.put("material_id", materialId)
                segment.put("source_timerange", JSONObject().put("start", 0).put("duration", durationUs))
                segment.put("target_timerange", JSONObject().put("start", targetStartUs).put("duration", durationUs))
                segment.put("render_timerange", JSONObject().put("start", 0).put("duration", 0))
                segment.put("render_index", renderIndex)
                segment.put("track_render_index", renderIndex)
                segment.put("common_keyframes", convertTransformKeyframes(occurrence.element, durationUs, sceneWidth, sceneHeight))
                applyStaticTransform(occurrence.element, segment, sceneWidth, sceneHeight)
                segment.put("keyframe_refs", JSONArray())
                val track = jsonClone(videoTrackSource)
                track.put("id", UUID.randomUUID().toString().uppercase())
                track.put("name", "SUJ XML Foto ${index + 1}")
                track.put("render_index", renderIndex)
                track.put("track_render_index", renderIndex)
                track.put("segments", JSONArray().put(segment))
                track.put("attribute", 0)
                baseTracks.put(track)
                renderIndex++
                totalUs = maxOf(totalUs, targetStartUs + durationUs)

                // Map effects only where a matching CapCut effect exists in the supplied project.
                val effectNodes = occurrence.element.childNodes
                for (e in 0 until effectNodes.length) {
                    val effect = effectNodes.item(e) as? Element ?: continue
                    if (tagName(effect) != "effect") continue
                    val wantedName = effectTemplateName(attr(effect, "id")) ?: continue
                    var sourceEffectTrack: JSONObject? = null
                    for (ti in 0 until baseTracks.length()) {
                        val candidate = baseTracks.getJSONObject(ti)
                        if (candidate.optString("type") != "effect") continue
                        val candidateSegment = candidate.optJSONArray("segments")?.optJSONObject(0) ?: continue
                        val matId = candidateSegment.optString("material_id")
                        val mats = materials.optJSONArray("video_effects") ?: continue
                        for (mi in 0 until mats.length()) {
                            val mat = mats.optJSONObject(mi) ?: continue
                            if (mat.optString("id") == matId && mat.optString("name").equals(wantedName, true)) {
                                sourceEffectTrack = candidate
                                break
                            }
                        }
                        if (sourceEffectTrack != null) break
                    }
                    val effectSource = sourceEffectTrack ?: continue
                    val effectSegmentSource = effectSource.getJSONArray("segments").getJSONObject(0)
                    val effectSegment = jsonClone(effectSegmentSource)
                    val sourceMaterial = (materials.optJSONArray("video_effects") ?: JSONArray()).let { list ->
                        (0 until list.length()).mapNotNull { list.optJSONObject(it) }
                            .firstOrNull { it.optString("id") == effectSegmentSource.optString("material_id") }
                    } ?: continue
                    val clonedMaterialId = cloneEffectMaterial(sourceMaterial, effect, materials)
                    effectSegment.put("material_id", clonedMaterialId)
                    effectSegment.put("id", UUID.randomUUID().toString().uppercase())
                    effectSegment.put("source_timerange", JSONObject().put("start", 0).put("duration", durationUs))
                    effectSegment.put("target_timerange", JSONObject().put("start", targetStartUs).put("duration", durationUs))
                    effectSegment.put("render_index", renderIndex)
                    effectSegment.put("track_render_index", renderIndex)
                    effectSegment.put("common_keyframes", convertEffectKeyframes(effect, durationUs))
                    effectSegment.put("keyframe_refs", JSONArray())
                    val effectTrack = jsonClone(effectSource)
                    effectTrack.put("id", UUID.randomUUID().toString().uppercase())
                    effectTrack.put("name", "SUJ XML ${wantedName} ${index + 1}")
                    effectTrack.put("render_index", renderIndex)
                    effectTrack.put("track_render_index", renderIndex)
                    effectTrack.put("segments", JSONArray().put(effectSegment))
                    baseTracks.put(effectTrack)
                    renderIndex++
                }
            }

            draft.put("tracks", baseTracks)
            draft.put("duration", totalUs)
            draft.put("name", draftName)
            draft.put("fps", attr(scene, "fps").toDoubleOrNull() ?: draft.optDouble("fps", 30.0))
            val timelineId = UUID.randomUUID().toString().uppercase()
            draft.put("id", timelineId)

            projectInfo.put("id", UUID.randomUUID().toString().uppercase())
            projectInfo.put("main_timeline_id", timelineId)
            val timelineList = projectInfo.optJSONArray("timelines") ?: JSONArray()
            if (timelineList.length() > 0) timelineList.getJSONObject(0).put("id", timelineId)

            val meta = readBaseProjectJson("1121/draft_meta_info.json")
            meta.put("draft_id", UUID.randomUUID().toString().uppercase())
            meta.put("draft_name", draftName)
            meta.put("draft_fold_path", "")
            meta.put("draft_root_path", "")
            meta.put("draft_materials", JSONArray())
            meta.put("draft_timeline_materials_size_", mediaBytes.values.sumOf { it.size })
            meta.put("tm_duration", totalUs)

            contentResolver.openOutputStream(uri)?.use { raw ->
                ZipOutputStream(raw).use { zip ->
                    fun addText(path: String, text: String) {
                        zip.putNextEntry(ZipEntry(path)); zip.write(text.toByteArray(Charsets.UTF_8)); zip.closeEntry()
                    }
                    val folder = draftName.replace(Regex("[^A-Za-z0-9._ -]"), "_").ifBlank { "SUJ_PROJECT" }
                    val prefix = "$folder/"
                    val timelineFolder = "${prefix}Timelines/$timelineId/"
                    ZipInputStream(assets.open("capcut_base_project.zip")).use { baseZip ->
                        while (true) {
                            val entry = baseZip.nextEntry ?: break
                            if (entry.isDirectory || !entry.name.startsWith("1121/")) continue
                            val relative = entry.name.removePrefix("1121/")
                            if (relative == "draft_content.json" || relative == "draft_meta_info.json" ||
                                relative == "Timelines/project.json" || relative == "draft_content.json.bak" ||
                                relative.endsWith("/draft_content.json") || relative.endsWith("/draft_content.json.bak")) continue
                            val renamed = relative.replace("Timelines/$originalTimelineId/", "Timelines/$timelineId/")
                            val outputName = prefix + renamed
                            zip.putNextEntry(ZipEntry(outputName)); baseZip.copyTo(zip); zip.closeEntry()
                        }
                    }
                    addText(prefix + "draft_content.json", draft.toString(2))
                    addText(prefix + "draft_meta_info.json", meta.toString(2))
                    addText(prefix + "Timelines/project.json", projectInfo.toString(2))
                    addText(timelineFolder + "draft_content.json", draft.toString(2))
                    mediaBytes.forEach { (name, bytes) ->
                        zip.putNextEntry(ZipEntry(prefix + "media/$name")); zip.write(bytes); zip.closeEntry()
                    }
                    addText(prefix + "README_IMPORT.txt", "SUJ PROJECT - Paket proyek CapCut PC\n\nSetiap kemunculan foto XML dibuat sebagai track terpisah agar urutan, overlap, dan z-order terjaga. Transform posisi, skala X/Y, rotasi, opacity, easing cubic-bezier, fade-in, dan fade-out diterjemahkan ke keyframe CapCut. Foto disalin dari file asli tanpa kompresi ulang.\n\nEfek Alight Motion dipetakan secara pendekatan ke material efek CapCut yang tersedia: Gaussian Blur, Motion Blur, Oscillate/Swing, Ripple/Wave Warp, Tile/Mirror, Random Displace/Displace Map/Stretch, RGB separation, Exposure, Lift, dan Saturation/Vibrance. Efek kompleks seperti Luma Key, Four Color Gradient, dan beberapa efek khusus tidak memiliki padanan satu-ke-satu di template CapCut; hasilnya mungkin berbeda dari Alight Motion.\n\nEkstrak folder '$folder' ke folder Drafts CapCut PC. Jika foto belum ditemukan, relink foto dari folder media.\n")
                }
            } ?: error("Tidak dapat membuat file ZIP")

            bottomStatus.text = "Proyek CapCut dibuat: ${occurrences.size} bagian foto, ${mediaRefs.size} foto sumber, track asli dipertahankan."
            bottomStatus.setTextColor(green)
            Toast.makeText(this, "Proyek CapCut berhasil dibuat", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            bottomStatus.text = "Gagal membuat proyek: ${e.message ?: "kesalahan tidak diketahui"}"
            bottomStatus.setTextColor(Color.RED)
            Toast.makeText(this, "Gagal membuat proyek CapCut", Toast.LENGTH_LONG).show()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

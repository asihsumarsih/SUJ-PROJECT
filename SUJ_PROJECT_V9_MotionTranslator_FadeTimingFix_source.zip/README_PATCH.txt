SUJ PROJECT V9 - Fade timing correction

Perubahan:
- Memperbaiki konversi Fade In/Fade Out: seluruh waktu keyframe konsisten dalam detik sebelum dikonversi ke mikrodetik CapCut.
- Sebelumnya waktu Fade dihitung sebagai fraksi 0..1 lalu diperlakukan sebagai detik sehingga fade terlalu cepat.
- Tidak mengubah alur tombol Simpan, struktur ekspor, atau penambahan audio.

Status:
- ZIP diperiksa integritasnya.
- Build Android/Gradle dan uji buka proyek di CapCut belum dijalankan.
- Beberapa efek Alight Motion tidak memiliki padanan satu-ke-satu di template CapCut; kemiripan visual tetap perlu diuji.
